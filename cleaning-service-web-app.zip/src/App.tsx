import { ChangeEvent, FormEvent, ReactNode, useEffect, useMemo, useState } from "react";

type Role = "admin" | "user";
type TabKey =
  | "dashboard"
  | "master"
  | "stock"
  | "sales"
  | "documents"
  | "reports"
  | "profit"
  | "storage";
type CatalogKind = "barang" | "jasa";
type ContactType = "supplier" | "pelanggan";
type ReportPeriod = "harian" | "mingguan" | "bulanan" | "tahunan";
type StorageTarget = "virtual-disk" | "google-drive";

type Account = {
  username: string;
  password: string;
  role: Role;
  name: string;
};

type Contact = {
  id: string;
  type: ContactType;
  name: string;
  phone: string;
  address: string;
};

type CatalogItem = {
  id: string;
  kind: CatalogKind;
  name: string;
  unit: string;
  purchasePrice: number;
  salePrice: number;
  discount: number;
  supplierId: string;
  stock: number;
  minimumStock: number;
  soldCount: number;
};

type SaleLine = {
  id: string;
  itemId: string;
  name: string;
  kind: CatalogKind;
  qty: number;
  unit: string;
  unitPrice: number;
  purchasePrice: number;
  discount: number;
  subtotal: number;
};

type SaleRecord = {
  id: string;
  code: string;
  date: string;
  customerId: string;
  customerName: string;
  shippingAddress: string;
  notes: string;
  items: SaleLine[];
  subtotal: number;
  discountAmount: number;
  total: number;
};

type ExpenseRecord = {
  id: string;
  date: string;
  category: string;
  description: string;
  amount: number;
};

type AppData = {
  contacts: Contact[];
  catalog: CatalogItem[];
  sales: SaleRecord[];
  expenses: ExpenseRecord[];
  storage: {
    target: StorageTarget;
    lastBackupAt: string | null;
  };
};

type Notice = {
  type: "success" | "error" | "info";
  text: string;
};

const STORAGE_KEY = "cleanpro-cleaning-sales-v1";

const ACCOUNTS: Account[] = [
  {
    username: "admin",
    password: "admin123",
    role: "admin",
    name: "Administrator",
  },
  {
    username: "user",
    password: "user123",
    role: "user",
    name: "Petugas Penjualan",
  },
];

const tabs: Array<{ key: TabKey; label: string; description: string }> = [
  { key: "dashboard", label: "Dashboard", description: "Ringkasan informasi usaha" },
  { key: "master", label: "Master Data", description: "Barang, jasa, supplier, pelanggan" },
  { key: "stock", label: "Stok & Trend", description: "Kontrol persediaan dan tren penjualan" },
  { key: "sales", label: "Penjualan", description: "Input transaksi barang dan jasa" },
  { key: "documents", label: "Invoice & Surat Jalan", description: "Dokumen transaksi dan pengiriman" },
  { key: "reports", label: "Laporan Keuangan", description: "Harian, mingguan, bulanan, tahunan" },
  { key: "profit", label: "Neraca & Laba Rugi", description: "Neraca internal dan biaya operasional" },
  { key: "storage", label: "Backup & Print", description: "Ekspor, impor, cetak PDF/printer" },
];

function uid(prefix: string) {
  return `${prefix}-${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-4)}`;
}

function todayValue() {
  return formatDateInput(new Date());
}

function parseDate(value: string) {
  const [year, month, day] = value.split("-").map(Number);
  return new Date(year, (month || 1) - 1, day || 1);
}

function addDays(date: Date, offset: number) {
  const next = new Date(date);
  next.setDate(next.getDate() + offset);
  return next;
}

function formatDateInput(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function startOfWeek(date: Date) {
  const next = new Date(date);
  const day = (next.getDay() + 6) % 7;
  next.setDate(next.getDate() - day);
  return next;
}

function endOfWeek(date: Date) {
  return addDays(startOfWeek(date), 6);
}

function formatCurrency(value: number) {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0,
  }).format(value);
}

function formatNumber(value: number) {
  return new Intl.NumberFormat("id-ID").format(value);
}

function formatDateLabel(value: string) {
  return new Intl.DateTimeFormat("id-ID", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  }).format(parseDate(value));
}

function formatMonthLabel(value: string) {
  return new Intl.DateTimeFormat("id-ID", {
    month: "long",
    year: "numeric",
  }).format(parseDate(value));
}

function computeLineSubtotal(unitPrice: number, qty: number, discount: number) {
  const gross = unitPrice * qty;
  return gross - gross * (discount / 100);
}

function escapeHtml(value: string) {
  const map: Record<string, string> = {
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;",
  };

  return value.replace(/[&<>"']/g, (char) => map[char]);
}

function createDefaultData(): AppData {
  const base = parseDate(todayValue());
  const yesterday = formatDateInput(addDays(base, -1));
  const threeDaysAgo = formatDateInput(addDays(base, -3));
  const sixDaysAgo = formatDateInput(addDays(base, -6));

  const contacts: Contact[] = [
    {
      id: "sup-1",
      type: "supplier",
      name: "PT Kimia Bersih",
      phone: "021-555-1001",
      address: "Jl. Industri Bersih No. 10, Jakarta",
    },
    {
      id: "sup-2",
      type: "supplier",
      name: "CV Wangi Lestari",
      phone: "021-555-1002",
      address: "Jl. Melati No. 8, Tangerang",
    },
    {
      id: "cust-1",
      type: "pelanggan",
      name: "Hotel Mawar",
      phone: "021-555-2001",
      address: "Jl. Pahlawan No. 12, Jakarta Pusat",
    },
    {
      id: "cust-2",
      type: "pelanggan",
      name: "Klinik Sehat Sentosa",
      phone: "021-555-2002",
      address: "Jl. Dahlia No. 24, Depok",
    },
    {
      id: "cust-3",
      type: "pelanggan",
      name: "Resto Nusantara",
      phone: "021-555-2003",
      address: "Jl. Veteran No. 45, Bekasi",
    },
  ];

  const catalog: CatalogItem[] = [
    {
      id: "item-1",
      kind: "barang",
      name: "Cairan Pembersih Lantai",
      unit: "liter",
      purchasePrice: 25000,
      salePrice: 40000,
      discount: 5,
      supplierId: "sup-1",
      stock: 53,
      minimumStock: 20,
      soldCount: 7,
    },
    {
      id: "item-2",
      kind: "barang",
      name: "Sabun Cuci Serbaguna",
      unit: "dus",
      purchasePrice: 120000,
      salePrice: 165000,
      discount: 3,
      supplierId: "sup-2",
      stock: 22,
      minimumStock: 10,
      soldCount: 2,
    },
    {
      id: "item-3",
      kind: "jasa",
      name: "Jasa Deep Cleaning Office",
      unit: "sesi",
      purchasePrice: 150000,
      salePrice: 350000,
      discount: 10,
      supplierId: "sup-1",
      stock: 0,
      minimumStock: 0,
      soldCount: 1,
    },
    {
      id: "item-4",
      kind: "jasa",
      name: "Jasa Fogging Disinfektan",
      unit: "area",
      purchasePrice: 100000,
      salePrice: 250000,
      discount: 5,
      supplierId: "sup-2",
      stock: 0,
      minimumStock: 0,
      soldCount: 1,
    },
  ];

  const sales: SaleRecord[] = [
    {
      id: "sale-1",
      code: `INV-${base.getFullYear()}-0001`,
      date: yesterday,
      customerId: "cust-1",
      customerName: "Hotel Mawar",
      shippingAddress: "Jl. Pahlawan No. 12, Jakarta Pusat",
      notes: "Pengiriman pagi untuk housekeeping hotel.",
      items: [
        {
          id: "line-1",
          itemId: "item-1",
          name: "Cairan Pembersih Lantai",
          kind: "barang",
          qty: 4,
          unit: "liter",
          unitPrice: 40000,
          purchasePrice: 25000,
          discount: 5,
          subtotal: 152000,
        },
        {
          id: "line-2",
          itemId: "item-3",
          name: "Jasa Deep Cleaning Office",
          kind: "jasa",
          qty: 1,
          unit: "sesi",
          unitPrice: 350000,
          purchasePrice: 150000,
          discount: 10,
          subtotal: 315000,
        },
      ],
      subtotal: 510000,
      discountAmount: 43000,
      total: 467000,
    },
    {
      id: "sale-2",
      code: `INV-${base.getFullYear()}-0002`,
      date: threeDaysAgo,
      customerId: "cust-2",
      customerName: "Klinik Sehat Sentosa",
      shippingAddress: "Jl. Dahlia No. 24, Depok",
      notes: "Tambahan stok untuk ruang tindakan.",
      items: [
        {
          id: "line-3",
          itemId: "item-2",
          name: "Sabun Cuci Serbaguna",
          kind: "barang",
          qty: 2,
          unit: "dus",
          unitPrice: 165000,
          purchasePrice: 120000,
          discount: 3,
          subtotal: 320100,
        },
      ],
      subtotal: 330000,
      discountAmount: 9900,
      total: 320100,
    },
    {
      id: "sale-3",
      code: `INV-${base.getFullYear()}-0003`,
      date: sixDaysAgo,
      customerId: "cust-3",
      customerName: "Resto Nusantara",
      shippingAddress: "Jl. Veteran No. 45, Bekasi",
      notes: "Pembersihan area dapur dan gudang.",
      items: [
        {
          id: "line-4",
          itemId: "item-1",
          name: "Cairan Pembersih Lantai",
          kind: "barang",
          qty: 3,
          unit: "liter",
          unitPrice: 40000,
          purchasePrice: 25000,
          discount: 5,
          subtotal: 114000,
        },
        {
          id: "line-5",
          itemId: "item-4",
          name: "Jasa Fogging Disinfektan",
          kind: "jasa",
          qty: 1,
          unit: "area",
          unitPrice: 250000,
          purchasePrice: 100000,
          discount: 5,
          subtotal: 237500,
        },
      ],
      subtotal: 370000,
      discountAmount: 18500,
      total: 351500,
    },
  ];

  const expenses: ExpenseRecord[] = [
    {
      id: "exp-1",
      date: yesterday,
      category: "Operasional",
      description: "Bensin pengiriman barang dan jasa",
      amount: 75000,
    },
    {
      id: "exp-2",
      date: threeDaysAgo,
      category: "Transport",
      description: "Biaya tol dan parkir tim lapangan",
      amount: 50000,
    },
    {
      id: "exp-3",
      date: sixDaysAgo,
      category: "Gaji Harian",
      description: "Upah petugas cleaning freelance",
      amount: 200000,
    },
  ];

  return {
    contacts,
    catalog,
    sales,
    expenses,
    storage: {
      target: "virtual-disk",
      lastBackupAt: null,
    },
  };
}

function normalizeData(raw: unknown): AppData {
  const fallback = createDefaultData();

  if (!raw || typeof raw !== "object") {
    return fallback;
  }

  const value = raw as Partial<AppData>;

  return {
    contacts: Array.isArray(value.contacts) ? value.contacts : fallback.contacts,
    catalog: Array.isArray(value.catalog) ? value.catalog : fallback.catalog,
    sales: Array.isArray(value.sales) ? value.sales : fallback.sales,
    expenses: Array.isArray(value.expenses) ? value.expenses : fallback.expenses,
    storage: {
      target:
        value.storage?.target === "google-drive" || value.storage?.target === "virtual-disk"
          ? value.storage.target
          : fallback.storage.target,
      lastBackupAt:
        typeof value.storage?.lastBackupAt === "string" || value.storage?.lastBackupAt === null
          ? value.storage.lastBackupAt ?? null
          : fallback.storage.lastBackupAt,
    },
  };
}

function loadInitialData() {
  if (typeof window === "undefined") {
    return createDefaultData();
  }

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      return createDefaultData();
    }

    return normalizeData(JSON.parse(raw));
  } catch {
    return createDefaultData();
  }
}

function SectionCard({
  title,
  subtitle,
  action,
  children,
  className = "",
}: {
  title: string;
  subtitle?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={`rounded-3xl border border-slate-200 bg-white p-6 shadow-sm ${className}`}>
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h2 className="text-lg font-semibold text-slate-900">{title}</h2>
          {subtitle ? <p className="mt-1 text-sm text-slate-500">{subtitle}</p> : null}
        </div>
        {action ? <div className="shrink-0">{action}</div> : null}
      </div>
      {children}
    </section>
  );
}

function MetricCard({
  label,
  value,
  helper,
}: {
  label: string;
  value: string;
  helper: string;
}) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-slate-50 p-5">
      <p className="text-sm font-medium text-slate-500">{label}</p>
      <p className="mt-2 text-2xl font-semibold text-slate-900">{value}</p>
      <p className="mt-2 text-sm text-slate-500">{helper}</p>
    </div>
  );
}

function Badge({
  tone = "slate",
  children,
}: {
  tone?: "slate" | "green" | "amber" | "red" | "blue" | "violet";
  children: ReactNode;
}) {
  const tones: Record<string, string> = {
    slate: "bg-slate-100 text-slate-700",
    green: "bg-emerald-100 text-emerald-700",
    amber: "bg-amber-100 text-amber-700",
    red: "bg-rose-100 text-rose-700",
    blue: "bg-sky-100 text-sky-700",
    violet: "bg-violet-100 text-violet-700",
  };

  return (
    <span className={`inline-flex items-center rounded-full px-3 py-1 text-xs font-semibold ${tones[tone]}`}>
      {children}
    </span>
  );
}

function EmptyState({ title, description }: { title: string; description: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-6 py-10 text-center">
      <h3 className="text-base font-semibold text-slate-900">{title}</h3>
      <p className="mt-2 text-sm text-slate-500">{description}</p>
    </div>
  );
}

export function App() {
  const [session, setSession] = useState<Account | null>(null);
  const [data, setData] = useState<AppData>(loadInitialData);
  const [activeTab, setActiveTab] = useState<TabKey>("dashboard");
  const [notice, setNotice] = useState<Notice | null>({
    type: "info",
    text: "Data demo siap dipakai dan akan tersimpan otomatis di browser.",
  });
  const [loginForm, setLoginForm] = useState({ username: "admin", password: "admin123" });
  const [contactForm, setContactForm] = useState({
    type: "supplier" as ContactType,
    name: "",
    phone: "",
    address: "",
  });
  const [itemForm, setItemForm] = useState({
    kind: "barang" as CatalogKind,
    name: "",
    unit: "pcs",
    purchasePrice: "",
    salePrice: "",
    discount: "0",
    supplierId: "",
    stock: "0",
    minimumStock: "0",
  });
  const [saleDraft, setSaleDraft] = useState({
    customerId: "",
    date: todayValue(),
    shippingAddress: "",
    notes: "",
    items: [] as SaleLine[],
  });
  const [lineDraft, setLineDraft] = useState({ itemId: "", qty: "1" });
  const [selectedSaleId, setSelectedSaleId] = useState<string>("");
  const [reportPeriod, setReportPeriod] = useState<ReportPeriod>("bulanan");
  const [reportDate, setReportDate] = useState(todayValue());
  const [expenseForm, setExpenseForm] = useState({
    date: todayValue(),
    category: "Operasional",
    description: "",
    amount: "",
  });

  useEffect(() => {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }, [data]);

  useEffect(() => {
    if (!notice) return undefined;
    const timer = window.setTimeout(() => setNotice(null), 4500);
    return () => window.clearTimeout(timer);
  }, [notice]);

  useEffect(() => {
    if (!selectedSaleId && data.sales.length > 0) {
      setSelectedSaleId(data.sales[0].id);
    }
  }, [data.sales, selectedSaleId]);

  const contactMap = useMemo(
    () => Object.fromEntries(data.contacts.map((contact) => [contact.id, contact])),
    [data.contacts]
  );

  const suppliers = useMemo(
    () => data.contacts.filter((contact) => contact.type === "supplier"),
    [data.contacts]
  );

  const customers = useMemo(
    () => data.contacts.filter((contact) => contact.type === "pelanggan"),
    [data.contacts]
  );

  const lowStockItems = useMemo(
    () =>
      data.catalog.filter(
        (item) => item.kind === "barang" && item.stock <= item.minimumStock
      ),
    [data.catalog]
  );

  const inventoryValue = useMemo(
    () =>
      data.catalog.reduce(
        (sum, item) => sum + (item.kind === "barang" ? item.stock * item.purchasePrice : 0),
        0
      ),
    [data.catalog]
  );

  const todayRevenue = useMemo(
    () =>
      data.sales
        .filter((sale) => sale.date === todayValue())
        .reduce((sum, sale) => sum + sale.total, 0),
    [data.sales]
  );

  const monthlyRevenue = useMemo(() => {
    const ref = parseDate(todayValue());
    return data.sales
      .filter((sale) => {
        const date = parseDate(sale.date);
        return date.getMonth() === ref.getMonth() && date.getFullYear() === ref.getFullYear();
      })
      .reduce((sum, sale) => sum + sale.total, 0);
  }, [data.sales]);

  const monthlyCost = useMemo(() => {
    const ref = parseDate(todayValue());
    return data.sales
      .filter((sale) => {
        const date = parseDate(sale.date);
        return date.getMonth() === ref.getMonth() && date.getFullYear() === ref.getFullYear();
      })
      .reduce(
        (sum, sale) =>
          sum + sale.items.reduce((lineSum, line) => lineSum + line.purchasePrice * line.qty, 0),
        0
      );
  }, [data.sales]);

  const monthlyExpense = useMemo(() => {
    const ref = parseDate(todayValue());
    return data.expenses
      .filter((expense) => {
        const date = parseDate(expense.date);
        return date.getMonth() === ref.getMonth() && date.getFullYear() === ref.getFullYear();
      })
      .reduce((sum, expense) => sum + expense.amount, 0);
  }, [data.expenses]);

  const monthlyNetProfit = monthlyRevenue - monthlyCost - monthlyExpense;

  const topSellingItems = useMemo(
    () => [...data.catalog].sort((a, b) => b.soldCount - a.soldCount).slice(0, 5),
    [data.catalog]
  );

  const trendData = useMemo(() => {
    const today = parseDate(todayValue());
    return Array.from({ length: 7 }, (_, index) => {
      const date = addDays(today, index - 6);
      const key = formatDateInput(date);
      const total = data.sales
        .filter((sale) => sale.date === key)
        .reduce((sum, sale) => sum + sale.total, 0);
      return {
        date: key,
        label: new Intl.DateTimeFormat("id-ID", {
          day: "2-digit",
          month: "2-digit",
        }).format(date),
        total,
      };
    });
  }, [data.sales]);

  const maxTrend = Math.max(...trendData.map((item) => item.total), 1);
  const maxTopSelling = Math.max(...topSellingItems.map((item) => item.soldCount), 1);

  const selectedSale = useMemo(
    () => data.sales.find((sale) => sale.id === selectedSaleId) ?? null,
    [data.sales, selectedSaleId]
  );

  const draftGross = saleDraft.items.reduce((sum, item) => sum + item.qty * item.unitPrice, 0);
  const draftTotal = saleDraft.items.reduce((sum, item) => sum + item.subtotal, 0);
  const draftDiscount = draftGross - draftTotal;

  const reportLabel = useMemo(() => {
    if (!reportDate) return "Periode belum dipilih";
    const ref = parseDate(reportDate);

    if (reportPeriod === "harian") {
      return formatDateLabel(reportDate);
    }

    if (reportPeriod === "mingguan") {
      const start = formatDateInput(startOfWeek(ref));
      const end = formatDateInput(endOfWeek(ref));
      return `${formatDateLabel(start)} - ${formatDateLabel(end)}`;
    }

    if (reportPeriod === "bulanan") {
      return formatMonthLabel(reportDate);
    }

    return `${ref.getFullYear()}`;
  }, [reportDate, reportPeriod]);

  const matchesPeriod = (dateValue: string) => {
    const target = parseDate(dateValue);
    const ref = parseDate(reportDate);

    if (reportPeriod === "harian") {
      return formatDateInput(target) === formatDateInput(ref);
    }

    if (reportPeriod === "mingguan") {
      const start = startOfWeek(ref).getTime();
      const end = endOfWeek(ref).getTime();
      const compare = target.getTime();
      return compare >= start && compare <= end;
    }

    if (reportPeriod === "bulanan") {
      return target.getMonth() === ref.getMonth() && target.getFullYear() === ref.getFullYear();
    }

    return target.getFullYear() === ref.getFullYear();
  };

  const reportSales = useMemo(
    () => data.sales.filter((sale) => matchesPeriod(sale.date)),
    [data.sales, reportDate, reportPeriod]
  );

  const reportExpenses = useMemo(
    () => data.expenses.filter((expense) => matchesPeriod(expense.date)),
    [data.expenses, reportDate, reportPeriod]
  );

  const reportRevenue = reportSales.reduce((sum, sale) => sum + sale.total, 0);
  const reportCost = reportSales.reduce(
    (sum, sale) => sum + sale.items.reduce((lineSum, line) => lineSum + line.purchasePrice * line.qty, 0),
    0
  );
  const reportDiscount = reportSales.reduce((sum, sale) => sum + sale.discountAmount, 0);
  const reportExpenseTotal = reportExpenses.reduce((sum, expense) => sum + expense.amount, 0);
  const reportGrossProfit = reportRevenue - reportCost;
  const reportNetProfit = reportGrossProfit - reportExpenseTotal;

  const allRevenue = data.sales.reduce((sum, sale) => sum + sale.total, 0);
  const allCost = data.sales.reduce(
    (sum, sale) => sum + sale.items.reduce((lineSum, line) => lineSum + line.purchasePrice * line.qty, 0),
    0
  );
  const allExpenses = data.expenses.reduce((sum, expense) => sum + expense.amount, 0);
  const grossProfit = allRevenue - allCost;
  const netProfit = grossProfit - allExpenses;
  const totalAssets = inventoryValue + netProfit;
  const totalLiabilities = 0;
  const totalEquity = totalAssets - totalLiabilities;

  const canManageAdminOnly = session?.role === "admin";

  const updateNotice = (type: Notice["type"], text: string) => {
    setNotice({ type, text });
  };

  const requireAdmin = (actionLabel: string) => {
    if (session?.role !== "admin") {
      updateNotice("error", `Aksi ${actionLabel} hanya tersedia untuk akun admin.`);
      return false;
    }
    return true;
  };

  const handleLogin = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const account = ACCOUNTS.find(
      (item) => item.username === loginForm.username && item.password === loginForm.password
    );

    if (!account) {
      updateNotice("error", "Username atau password tidak sesuai.");
      return;
    }

    setSession(account);
    setActiveTab("dashboard");
    updateNotice("success", `Login berhasil. Selamat datang, ${account.name}.`);
  };

  const handleAddContact = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!requireAdmin("tambah kontak")) return;

    if (!contactForm.name.trim()) {
      updateNotice("error", "Nama supplier atau pelanggan wajib diisi.");
      return;
    }

    const newContact: Contact = {
      id: uid(contactForm.type),
      type: contactForm.type,
      name: contactForm.name.trim(),
      phone: contactForm.phone.trim(),
      address: contactForm.address.trim(),
    };

    setData((prev) => ({
      ...prev,
      contacts: [newContact, ...prev.contacts],
    }));

    setContactForm({ type: "supplier", name: "", phone: "", address: "" });
    updateNotice("success", `${newContact.type === "supplier" ? "Supplier" : "Pelanggan"} berhasil ditambahkan.`);
  };

  const handleDeleteContact = (contact: Contact) => {
    if (!requireAdmin("hapus kontak")) return;

    const usedByCatalog = data.catalog.some((item) => item.supplierId === contact.id);
    const usedBySales = data.sales.some((sale) => sale.customerId === contact.id);

    if (usedByCatalog || usedBySales) {
      updateNotice(
        "error",
        "Kontak tidak dapat dihapus karena masih dipakai di data barang/jasa atau transaksi."
      );
      return;
    }

    if (!window.confirm(`Hapus ${contact.name}?`)) return;

    setData((prev) => ({
      ...prev,
      contacts: prev.contacts.filter((item) => item.id !== contact.id),
    }));

    updateNotice("success", "Kontak berhasil dihapus.");
  };

  const handleAddCatalogItem = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!requireAdmin("tambah barang/jasa")) return;

    if (!itemForm.name.trim()) {
      updateNotice("error", "Nama barang atau jasa wajib diisi.");
      return;
    }

    if (!itemForm.supplierId) {
      updateNotice("error", "Supplier wajib dipilih.");
      return;
    }

    const purchasePrice = Number(itemForm.purchasePrice);
    const salePrice = Number(itemForm.salePrice);
    const discount = Number(itemForm.discount);
    const stock = Number(itemForm.stock);
    const minimumStock = Number(itemForm.minimumStock);

    if (Number.isNaN(purchasePrice) || Number.isNaN(salePrice)) {
      updateNotice("error", "Harga beli dan harga jual wajib berupa angka.");
      return;
    }

    const newItem: CatalogItem = {
      id: uid("item"),
      kind: itemForm.kind,
      name: itemForm.name.trim(),
      unit: itemForm.unit.trim() || (itemForm.kind === "barang" ? "pcs" : "paket"),
      purchasePrice,
      salePrice,
      discount: Number.isNaN(discount) ? 0 : discount,
      supplierId: itemForm.supplierId,
      stock: itemForm.kind === "barang" ? (Number.isNaN(stock) ? 0 : stock) : 0,
      minimumStock: itemForm.kind === "barang" ? (Number.isNaN(minimumStock) ? 0 : minimumStock) : 0,
      soldCount: 0,
    };

    setData((prev) => ({
      ...prev,
      catalog: [newItem, ...prev.catalog],
    }));

    setItemForm({
      kind: "barang",
      name: "",
      unit: "pcs",
      purchasePrice: "",
      salePrice: "",
      discount: "0",
      supplierId: "",
      stock: "0",
      minimumStock: "0",
    });

    updateNotice("success", `${newItem.kind === "barang" ? "Barang" : "Jasa"} berhasil ditambahkan.`);
  };

  const handleDeleteCatalogItem = (item: CatalogItem) => {
    if (!requireAdmin("hapus barang/jasa")) return;

    const usedBySales = data.sales.some((sale) => sale.items.some((line) => line.itemId === item.id));
    if (usedBySales) {
      updateNotice("error", "Item tidak dapat dihapus karena sudah dipakai pada transaksi penjualan.");
      return;
    }

    if (!window.confirm(`Hapus ${item.name}?`)) return;

    setData((prev) => ({
      ...prev,
      catalog: prev.catalog.filter((catalogItem) => catalogItem.id !== item.id),
    }));

    updateNotice("success", "Barang/jasa berhasil dihapus.");
  };

  const handleAddSaleLine = () => {
    const selectedItem = data.catalog.find((item) => item.id === lineDraft.itemId);
    const qty = Number(lineDraft.qty);

    if (!selectedItem) {
      updateNotice("error", "Pilih barang atau jasa terlebih dahulu.");
      return;
    }

    if (Number.isNaN(qty) || qty <= 0) {
      updateNotice("error", "Jumlah item harus lebih dari 0.");
      return;
    }

    const existingLine = saleDraft.items.find((line) => line.itemId === selectedItem.id);
    const combinedQty = (existingLine?.qty ?? 0) + qty;

    if (selectedItem.kind === "barang" && combinedQty > selectedItem.stock) {
      updateNotice("error", `Stok ${selectedItem.name} tidak mencukupi untuk jumlah yang diminta.`);
      return;
    }

    const newSubtotal = computeLineSubtotal(selectedItem.salePrice, combinedQty, selectedItem.discount);

    setSaleDraft((prev) => {
      if (existingLine) {
        return {
          ...prev,
          items: prev.items.map((line) =>
            line.itemId === selectedItem.id
              ? {
                  ...line,
                  qty: combinedQty,
                  subtotal: newSubtotal,
                }
              : line
          ),
        };
      }

      return {
        ...prev,
        items: [
          ...prev.items,
          {
            id: uid("draft-line"),
            itemId: selectedItem.id,
            name: selectedItem.name,
            kind: selectedItem.kind,
            qty,
            unit: selectedItem.unit,
            unitPrice: selectedItem.salePrice,
            purchasePrice: selectedItem.purchasePrice,
            discount: selectedItem.discount,
            subtotal: computeLineSubtotal(selectedItem.salePrice, qty, selectedItem.discount),
          },
        ],
      };
    });

    setLineDraft({ itemId: "", qty: "1" });
    updateNotice("success", `${selectedItem.name} dimasukkan ke draft penjualan.`);
  };

  const handleRemoveDraftLine = (lineId: string) => {
    setSaleDraft((prev) => ({
      ...prev,
      items: prev.items.filter((line) => line.id !== lineId),
    }));
  };

  const handleSaveSale = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    const customer = customers.find((item) => item.id === saleDraft.customerId);
    if (!customer) {
      updateNotice("error", "Pilih pelanggan terlebih dahulu.");
      return;
    }

    if (saleDraft.items.length === 0) {
      updateNotice("error", "Tambahkan minimal satu barang/jasa ke draft penjualan.");
      return;
    }

    const saleId = uid("sale");
    const subtotal = saleDraft.items.reduce((sum, item) => sum + item.qty * item.unitPrice, 0);
    const total = saleDraft.items.reduce((sum, item) => sum + item.subtotal, 0);
    const discountAmount = subtotal - total;

    const newSale: SaleRecord = {
      id: saleId,
      code: `INV-${parseDate(saleDraft.date).getFullYear()}-${String(data.sales.length + 1).padStart(4, "0")}`,
      date: saleDraft.date,
      customerId: customer.id,
      customerName: customer.name,
      shippingAddress: saleDraft.shippingAddress.trim() || customer.address,
      notes: saleDraft.notes.trim(),
      items: saleDraft.items,
      subtotal,
      discountAmount,
      total,
    };

    setData((prev) => ({
      ...prev,
      sales: [newSale, ...prev.sales],
      catalog: prev.catalog.map((item) => {
        const soldItem = newSale.items.find((line) => line.itemId === item.id);
        if (!soldItem) return item;

        return {
          ...item,
          stock: item.kind === "barang" ? Math.max(item.stock - soldItem.qty, 0) : item.stock,
          soldCount: item.soldCount + soldItem.qty,
        };
      }),
    }));

    setSaleDraft({
      customerId: "",
      date: todayValue(),
      shippingAddress: "",
      notes: "",
      items: [],
    });
    setSelectedSaleId(saleId);
    setActiveTab("documents");
    updateNotice("success", `Penjualan ${newSale.code} berhasil disimpan.`);
  };

  const handleAddExpense = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!requireAdmin("tambah biaya operasional")) return;

    const amount = Number(expenseForm.amount);
    if (!expenseForm.description.trim() || Number.isNaN(amount) || amount <= 0) {
      updateNotice("error", "Deskripsi dan nominal biaya harus diisi dengan benar.");
      return;
    }

    const newExpense: ExpenseRecord = {
      id: uid("expense"),
      date: expenseForm.date,
      category: expenseForm.category.trim() || "Operasional",
      description: expenseForm.description.trim(),
      amount,
    };

    setData((prev) => ({
      ...prev,
      expenses: [newExpense, ...prev.expenses],
    }));

    setExpenseForm({
      date: todayValue(),
      category: "Operasional",
      description: "",
      amount: "",
    });
    updateNotice("success", "Biaya operasional berhasil ditambahkan.");
  };

  const handleDeleteExpense = (expenseId: string) => {
    if (!requireAdmin("hapus biaya operasional")) return;

    if (!window.confirm("Hapus biaya operasional ini?")) return;

    setData((prev) => ({
      ...prev,
      expenses: prev.expenses.filter((expense) => expense.id !== expenseId),
    }));
    updateNotice("success", "Biaya operasional berhasil dihapus.");
  };

  const openPrintWindow = (title: string, bodyHtml: string) => {
    const printWindow = window.open("", "_blank", "width=1024,height=768");

    if (!printWindow) {
      updateNotice("error", "Popup diblokir browser. Izinkan popup untuk mencetak dokumen.");
      return;
    }

    printWindow.document.write(`
      <!doctype html>
      <html lang="id">
        <head>
          <meta charset="UTF-8" />
          <meta name="viewport" content="width=device-width, initial-scale=1.0" />
          <title>${escapeHtml(title)}</title>
          <style>
            body { font-family: Arial, Helvetica, sans-serif; margin: 0; color: #0f172a; background: #fff; }
            .page { max-width: 900px; margin: 0 auto; padding: 32px; }
            .header { display: flex; justify-content: space-between; gap: 16px; align-items: flex-start; margin-bottom: 24px; }
            .brand { font-size: 28px; font-weight: 700; margin: 0 0 4px; }
            .muted { color: #64748b; margin: 0; font-size: 13px; }
            .grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 16px; margin-bottom: 24px; }
            .card { border: 1px solid #e2e8f0; border-radius: 18px; padding: 16px; }
            .card h3 { margin: 0 0 10px; font-size: 14px; text-transform: uppercase; color: #475569; letter-spacing: .08em; }
            .card p { margin: 4px 0; }
            table { width: 100%; border-collapse: collapse; margin-top: 16px; }
            th, td { border-bottom: 1px solid #e2e8f0; padding: 12px 10px; text-align: left; font-size: 13px; }
            th { color: #475569; background: #f8fafc; }
            .summary { margin-top: 20px; margin-left: auto; width: 320px; }
            .summary-row { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px dashed #cbd5e1; }
            .summary-row.total { font-size: 18px; font-weight: 700; border-bottom: 0; padding-top: 12px; }
            .note { margin-top: 24px; border-top: 1px solid #e2e8f0; padding-top: 16px; font-size: 13px; color: #475569; }
            .signature { margin-top: 48px; display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 24px; }
            .signature-box { text-align: center; }
            .signature-line { margin-top: 56px; border-top: 1px solid #94a3b8; padding-top: 10px; }
            @media print {
              .page { padding: 16px; }
            }
          </style>
        </head>
        <body>${bodyHtml}</body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    window.setTimeout(() => {
      printWindow.print();
    }, 400);
  };

  const printInvoice = (sale: SaleRecord) => {
    const customer = contactMap[sale.customerId];
    const rows = sale.items
      .map(
        (line) => `
          <tr>
            <td>${escapeHtml(line.name)}</td>
            <td>${escapeHtml(line.kind)}</td>
            <td>${line.qty} ${escapeHtml(line.unit)}</td>
            <td>${formatCurrency(line.unitPrice)}</td>
            <td>${line.discount}%</td>
            <td>${formatCurrency(line.subtotal)}</td>
          </tr>
        `
      )
      .join("");

    openPrintWindow(
      `Invoice ${sale.code}`,
      `
        <div class="page">
          <div class="header">
            <div>
              <p class="brand">CleanPro Sales</p>
              <p class="muted">Invoice penjualan barang & jasa cleaning</p>
            </div>
            <div style="text-align:right">
              <p><strong>No. Invoice:</strong> ${escapeHtml(sale.code)}</p>
              <p><strong>Tanggal:</strong> ${escapeHtml(formatDateLabel(sale.date))}</p>
            </div>
          </div>
          <div class="grid">
            <div class="card">
              <h3>Ditagihkan Kepada</h3>
              <p><strong>${escapeHtml(sale.customerName)}</strong></p>
              <p>${escapeHtml(customer?.phone || "-")}</p>
              <p>${escapeHtml(sale.shippingAddress)}</p>
            </div>
            <div class="card">
              <h3>Informasi Dokumen</h3>
              <p>Role login dapat mencetak langsung ke printer terinstal.</p>
              <p>Gunakan dialog print browser untuk simpan sebagai PDF.</p>
              <p>Catatan: ${escapeHtml(sale.notes || "-")}</p>
            </div>
          </div>
          <table>
            <thead>
              <tr>
                <th>Item</th>
                <th>Jenis</th>
                <th>Qty</th>
                <th>Harga</th>
                <th>Diskon</th>
                <th>Subtotal</th>
              </tr>
            </thead>
            <tbody>${rows}</tbody>
          </table>
          <div class="summary">
            <div class="summary-row"><span>Subtotal</span><strong>${formatCurrency(sale.subtotal)}</strong></div>
            <div class="summary-row"><span>Diskon</span><strong>${formatCurrency(sale.discountAmount)}</strong></div>
            <div class="summary-row total"><span>Total Bayar</span><strong>${formatCurrency(sale.total)}</strong></div>
          </div>
          <div class="note">
            Terima kasih telah menggunakan layanan CleanPro Sales. Dokumen ini sah tanpa tanda tangan basah.
          </div>
        </div>
      `
    );
  };

  const printDeliveryNote = (sale: SaleRecord) => {
    const customer = contactMap[sale.customerId];
    const rows = sale.items
      .map(
        (line) => `
          <tr>
            <td>${escapeHtml(line.name)}</td>
            <td>${line.qty} ${escapeHtml(line.unit)}</td>
            <td>${escapeHtml(line.kind === "barang" ? "Barang dikirim" : "Jasa dikerjakan")}</td>
          </tr>
        `
      )
      .join("");

    openPrintWindow(
      `Surat Jalan ${sale.code}`,
      `
        <div class="page">
          <div class="header">
            <div>
              <p class="brand">CleanPro Sales</p>
              <p class="muted">Surat jalan pengiriman barang dan pelaksanaan jasa</p>
            </div>
            <div style="text-align:right">
              <p><strong>No. Surat Jalan:</strong> SJ-${escapeHtml(sale.code)}</p>
              <p><strong>Tanggal:</strong> ${escapeHtml(formatDateLabel(sale.date))}</p>
            </div>
          </div>
          <div class="grid">
            <div class="card">
              <h3>Tujuan Pengiriman / Layanan</h3>
              <p><strong>${escapeHtml(sale.customerName)}</strong></p>
              <p>${escapeHtml(customer?.phone || "-")}</p>
              <p>${escapeHtml(sale.shippingAddress)}</p>
            </div>
            <div class="card">
              <h3>Keterangan</h3>
              <p>${escapeHtml(sale.notes || "Tidak ada catatan tambahan")}</p>
            </div>
          </div>
          <table>
            <thead>
              <tr>
                <th>Nama Item/Jasa</th>
                <th>Jumlah</th>
                <th>Keterangan</th>
              </tr>
            </thead>
            <tbody>${rows}</tbody>
          </table>
          <div class="signature">
            <div class="signature-box">
              <p>Disiapkan oleh</p>
              <div class="signature-line">Admin / User</div>
            </div>
            <div class="signature-box">
              <p>Pengirim / Teknisi</p>
              <div class="signature-line">Tim Lapangan</div>
            </div>
            <div class="signature-box">
              <p>Penerima</p>
              <div class="signature-line">${escapeHtml(sale.customerName)}</div>
            </div>
          </div>
        </div>
      `
    );
  };

  const printReport = () => {
    const salesRows = reportSales
      .map(
        (sale) => `
          <tr>
            <td>${escapeHtml(sale.code)}</td>
            <td>${escapeHtml(formatDateLabel(sale.date))}</td>
            <td>${escapeHtml(sale.customerName)}</td>
            <td>${sale.items.length}</td>
            <td>${formatCurrency(sale.total)}</td>
          </tr>
        `
      )
      .join("");

    const expenseRows = reportExpenses
      .map(
        (expense) => `
          <tr>
            <td>${escapeHtml(formatDateLabel(expense.date))}</td>
            <td>${escapeHtml(expense.category)}</td>
            <td>${escapeHtml(expense.description)}</td>
            <td>${formatCurrency(expense.amount)}</td>
          </tr>
        `
      )
      .join("");

    openPrintWindow(
      `Laporan ${reportPeriod} ${reportLabel}`,
      `
        <div class="page">
          <div class="header">
            <div>
              <p class="brand">CleanPro Sales</p>
              <p class="muted">Laporan keuangan ${escapeHtml(reportPeriod)}</p>
            </div>
            <div style="text-align:right">
              <p><strong>Periode:</strong> ${escapeHtml(reportLabel)}</p>
              <p><strong>Dicetak:</strong> ${escapeHtml(formatDateLabel(todayValue()))}</p>
            </div>
          </div>
          <div class="grid">
            <div class="card"><h3>Omzet</h3><p><strong>${formatCurrency(reportRevenue)}</strong></p></div>
            <div class="card"><h3>Diskon</h3><p><strong>${formatCurrency(reportDiscount)}</strong></p></div>
            <div class="card"><h3>HPP</h3><p><strong>${formatCurrency(reportCost)}</strong></p></div>
            <div class="card"><h3>Laba Bersih</h3><p><strong>${formatCurrency(reportNetProfit)}</strong></p></div>
          </div>
          <h3 style="margin-bottom:8px">Daftar Penjualan</h3>
          <table>
            <thead>
              <tr>
                <th>Invoice</th>
                <th>Tanggal</th>
                <th>Pelanggan</th>
                <th>Jumlah Item</th>
                <th>Total</th>
              </tr>
            </thead>
            <tbody>${salesRows || '<tr><td colspan="5">Tidak ada transaksi.</td></tr>'}</tbody>
          </table>
          <h3 style="margin:24px 0 8px">Biaya Operasional</h3>
          <table>
            <thead>
              <tr>
                <th>Tanggal</th>
                <th>Kategori</th>
                <th>Deskripsi</th>
                <th>Nominal</th>
              </tr>
            </thead>
            <tbody>${expenseRows || '<tr><td colspan="4">Tidak ada biaya pada periode ini.</td></tr>'}</tbody>
          </table>
        </div>
      `
    );
  };

  const handleExportBackup = () => {
    const exportData: AppData = {
      ...data,
      storage: {
        ...data.storage,
        lastBackupAt: new Date().toISOString(),
      },
    };

    setData(exportData);

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `cleanpro-${exportData.storage.target}-${todayValue()}.json`;
    anchor.click();
    URL.revokeObjectURL(url);

    updateNotice(
      "success",
      `Backup JSON berhasil dibuat. Simpan file ini ke ${exportData.storage.target === "google-drive" ? "Google Drive" : "virtual harddisk"}.`
    );
  };

  const handleImportBackup = (event: ChangeEvent<HTMLInputElement>) => {
    const input = event.currentTarget;
    const file = input.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        const normalized = normalizeData(parsed);
        setData(normalized);
        setSelectedSaleId(normalized.sales[0]?.id ?? "");
        updateNotice("success", "Backup berhasil diimpor.");
      } catch {
        updateNotice("error", "File backup tidak valid.");
      } finally {
        input.value = "";
      }
    };
    reader.readAsText(file);
  };

  const resetDemoData = () => {
    if (!requireAdmin("reset data demo")) return;
    if (!window.confirm("Reset seluruh data ke data demo awal?")) return;

    const fresh = createDefaultData();
    setData(fresh);
    setSelectedSaleId(fresh.sales[0]?.id ?? "");
    updateNotice("success", "Data demo berhasil dimuat ulang.");
  };

  if (!session) {
    return (
      <div className="min-h-screen bg-slate-950 text-white">
        <div className="mx-auto grid min-h-screen max-w-7xl items-center gap-10 px-6 py-12 lg:grid-cols-[1.2fr_0.8fr]">
          <div className="space-y-8">
            <Badge tone="blue">Aplikasi penjualan barang & jasa cleaning</Badge>
            <div className="space-y-4">
              <h1 className="max-w-3xl text-4xl font-semibold leading-tight sm:text-5xl">
                CleanPro Sales ERP untuk penjualan, stok, invoice, laporan, dan backup usaha cleaning.
              </h1>
              <p className="max-w-2xl text-lg text-slate-300">
                Sistem ini sudah menyiapkan login admin/user, master data barang & jasa, stok minimum,
                input penjualan, invoice, surat jalan, laporan keuangan, laba rugi, dan backup data ke
                virtual harddisk browser atau file JSON untuk Google Drive.
              </p>
            </div>
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {[
                "Dashboard informasi real-time",
                "Kelola supplier & pelanggan",
                "Cetak PDF / printer browser",
                "Laporan harian hingga tahunan",
                "Trend penjualan & stok minimum",
                "Backup, impor, dan restore data",
              ].map((feature) => (
                <div key={feature} className="rounded-2xl border border-white/10 bg-white/5 p-4 text-sm text-slate-200">
                  {feature}
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-3xl border border-white/10 bg-white p-6 text-slate-900 shadow-2xl shadow-slate-950/30 sm:p-8">
            <div className="mb-6 space-y-2">
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-sky-600">Login aplikasi</p>
              <h2 className="text-2xl font-semibold">Masuk ke CleanPro Sales</h2>
              <p className="text-sm text-slate-500">Gunakan akun demo berikut untuk mengakses aplikasi.</p>
            </div>

            <div className="mb-6 grid gap-3 sm:grid-cols-2">
              <button
                type="button"
                onClick={() => setLoginForm({ username: "admin", password: "admin123" })}
                className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-left transition hover:border-sky-300 hover:bg-sky-50"
              >
                <p className="font-semibold">Akun Admin</p>
                <p className="mt-1 text-sm text-slate-500">admin / admin123</p>
              </button>
              <button
                type="button"
                onClick={() => setLoginForm({ username: "user", password: "user123" })}
                className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-left transition hover:border-sky-300 hover:bg-sky-50"
              >
                <p className="font-semibold">Akun User</p>
                <p className="mt-1 text-sm text-slate-500">user / user123</p>
              </button>
            </div>

            <form className="space-y-4" onSubmit={handleLogin}>
              <label className="block space-y-2">
                <span className="text-sm font-medium text-slate-700">Username</span>
                <input
                  value={loginForm.username}
                  onChange={(event) =>
                    setLoginForm((prev) => ({ ...prev, username: event.target.value }))
                  }
                  className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none transition focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
                  placeholder="Masukkan username"
                />
              </label>
              <label className="block space-y-2">
                <span className="text-sm font-medium text-slate-700">Password</span>
                <input
                  type="password"
                  value={loginForm.password}
                  onChange={(event) =>
                    setLoginForm((prev) => ({ ...prev, password: event.target.value }))
                  }
                  className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none transition focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
                  placeholder="Masukkan password"
                />
              </label>
              <button
                type="submit"
                className="w-full rounded-2xl bg-slate-950 px-4 py-3 font-semibold text-white transition hover:bg-sky-700"
              >
                Masuk ke aplikasi
              </button>
            </form>

            {notice ? (
              <div
                className={`mt-5 rounded-2xl px-4 py-3 text-sm ${
                  notice.type === "error"
                    ? "bg-rose-50 text-rose-700"
                    : notice.type === "success"
                      ? "bg-emerald-50 text-emerald-700"
                      : "bg-sky-50 text-sky-700"
                }`}
              >
                {notice.text}
              </div>
            ) : null}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900">
      <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/90 backdrop-blur">
        <div className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <div>
            <div className="flex flex-wrap items-center gap-3">
              <h1 className="text-2xl font-semibold">CleanPro Sales ERP</h1>
              <Badge tone="blue">Login sebagai {session.role}</Badge>
              <Badge tone={data.storage.target === "google-drive" ? "violet" : "green"}>
                Penyimpanan: {data.storage.target === "google-drive" ? "Google Drive Backup" : "Virtual Harddisk Browser"}
              </Badge>
            </div>
            <p className="mt-2 text-sm text-slate-500">
              Dashboard penjualan barang & jasa cleaning untuk operasional harian, dokumen, laporan, dan backup data.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <div className="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-2 text-sm">
              <p className="font-semibold">{session.name}</p>
              <p className="text-slate-500">{session.username}</p>
            </div>
            <button
              type="button"
              onClick={() => {
                setSession(null);
                updateNotice("info", "Anda telah keluar dari aplikasi.");
              }}
              className="rounded-2xl border border-slate-300 bg-white px-4 py-2 font-medium transition hover:border-slate-400 hover:bg-slate-50"
            >
              Logout
            </button>
          </div>
        </div>
      </header>

      <div className="mx-auto grid max-w-7xl gap-6 px-4 py-6 sm:px-6 lg:grid-cols-[280px_1fr]">
        <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
          <div className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
            <p className="mb-3 px-2 text-xs font-semibold uppercase tracking-[0.2em] text-slate-500">Menu aplikasi</p>
            <div className="space-y-2">
              {tabs.map((tab) => (
                <button
                  key={tab.key}
                  type="button"
                  onClick={() => setActiveTab(tab.key)}
                  className={`w-full rounded-2xl px-4 py-3 text-left transition ${
                    activeTab === tab.key
                      ? "bg-slate-950 text-white shadow-lg shadow-slate-300/40"
                      : "bg-slate-50 text-slate-700 hover:bg-slate-100"
                  }`}
                >
                  <p className="font-semibold">{tab.label}</p>
                  <p className={`mt-1 text-xs ${activeTab === tab.key ? "text-slate-300" : "text-slate-500"}`}>
                    {tab.description}
                  </p>
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
            <h3 className="text-sm font-semibold text-slate-900">Akses pengguna</h3>
            <div className="mt-4 space-y-3 text-sm text-slate-600">
              <div className="rounded-2xl bg-slate-50 p-3">
                <p className="font-semibold text-slate-900">Admin</p>
                <p>Kelola master data, biaya, backup, reset data, dan semua transaksi.</p>
              </div>
              <div className="rounded-2xl bg-slate-50 p-3">
                <p className="font-semibold text-slate-900">User</p>
                <p>Lihat dashboard, input penjualan, cetak dokumen, dan buka laporan.</p>
              </div>
            </div>
          </div>
        </aside>

        <main className="space-y-6">
          {notice ? (
            <div
              className={`rounded-2xl px-4 py-3 text-sm font-medium ${
                notice.type === "error"
                  ? "border border-rose-200 bg-rose-50 text-rose-700"
                  : notice.type === "success"
                    ? "border border-emerald-200 bg-emerald-50 text-emerald-700"
                    : "border border-sky-200 bg-sky-50 text-sky-700"
              }`}
            >
              {notice.text}
            </div>
          ) : null}

          {activeTab === "dashboard" ? (
            <div className="space-y-6">
              <SectionCard
                title="Dashboard informasi"
                subtitle="Pantau performa usaha cleaning, omzet, stok kritis, dan backup data dalam satu tampilan."
              >
                <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                  <MetricCard
                    label="Omzet hari ini"
                    value={formatCurrency(todayRevenue)}
                    helper="Total penjualan berdasarkan tanggal hari ini"
                  />
                  <MetricCard
                    label="Omzet bulan berjalan"
                    value={formatCurrency(monthlyRevenue)}
                    helper="Akumulasi penjualan bulan ini"
                  />
                  <MetricCard
                    label="Laba bersih bulan ini"
                    value={formatCurrency(monthlyNetProfit)}
                    helper="Omzet - HPP - biaya operasional bulan ini"
                  />
                  <MetricCard
                    label="Stok minimum"
                    value={String(lowStockItems.length)}
                    helper="Jumlah barang yang sudah menyentuh batas minimum"
                  />
                </div>
              </SectionCard>

              <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
                <SectionCard
                  title="Trend omzet 7 hari terakhir"
                  subtitle="Visualisasi sederhana untuk membantu melihat ritme transaksi terbaru."
                >
                  <div className="space-y-4">
                    {trendData.map((item) => (
                      <div key={item.date} className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="font-medium text-slate-700">{item.label}</span>
                          <span className="text-slate-500">{formatCurrency(item.total)}</span>
                        </div>
                        <div className="h-3 overflow-hidden rounded-full bg-slate-100">
                          <div
                            className="h-full rounded-full bg-gradient-to-r from-sky-500 to-indigo-600"
                            style={{ width: `${Math.max((item.total / maxTrend) * 100, item.total > 0 ? 10 : 2)}%` }}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </SectionCard>

                <SectionCard
                  title="Status usaha"
                  subtitle="Informasi cepat mengenai inventaris, transaksi, dan penyimpanan."
                >
                  <div className="space-y-4 text-sm text-slate-600">
                    <div className="rounded-2xl bg-slate-50 p-4">
                      <p className="font-semibold text-slate-900">Nilai persediaan</p>
                      <p className="mt-1 text-xl font-semibold text-slate-900">{formatCurrency(inventoryValue)}</p>
                      <p className="mt-1">Estimasi nilai stok barang berdasarkan harga beli.</p>
                    </div>
                    <div className="rounded-2xl bg-slate-50 p-4">
                      <p className="font-semibold text-slate-900">Total transaksi</p>
                      <p className="mt-1 text-xl font-semibold text-slate-900">{formatNumber(data.sales.length)} transaksi</p>
                      <p className="mt-1">Termasuk penjualan barang dan jasa cleaning.</p>
                    </div>
                    <div className="rounded-2xl bg-slate-50 p-4">
                      <p className="font-semibold text-slate-900">Backup terakhir</p>
                      <p className="mt-1 text-slate-700">
                        {data.storage.lastBackupAt
                          ? new Intl.DateTimeFormat("id-ID", {
                              dateStyle: "medium",
                              timeStyle: "short",
                            }).format(new Date(data.storage.lastBackupAt))
                          : "Belum ada backup manual"}
                      </p>
                      <p className="mt-1">Data tetap auto-save di virtual harddisk browser.</p>
                    </div>
                  </div>
                </SectionCard>
              </div>

              <div className="grid gap-6 xl:grid-cols-2">
                <SectionCard
                  title="Top selling barang & jasa"
                  subtitle="Diambil dari total item/jasa terjual pada data transaksi."
                >
                  <div className="space-y-4">
                    {topSellingItems.length > 0 ? (
                      topSellingItems.map((item) => (
                        <div key={item.id} className="space-y-2">
                          <div className="flex items-center justify-between gap-4 text-sm">
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-slate-700">{item.name}</span>
                              <Badge tone={item.kind === "barang" ? "green" : "violet"}>{item.kind}</Badge>
                            </div>
                            <span className="text-slate-500">Terjual {formatNumber(item.soldCount)}</span>
                          </div>
                          <div className="h-3 overflow-hidden rounded-full bg-slate-100">
                            <div
                              className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-600"
                              style={{ width: `${Math.max((item.soldCount / maxTopSelling) * 100, 8)}%` }}
                            />
                          </div>
                        </div>
                      ))
                    ) : (
                      <EmptyState title="Belum ada data tren" description="Tambahkan transaksi untuk melihat item terlaris." />
                    )}
                  </div>
                </SectionCard>

                <SectionCard
                  title="Peringatan stok minimum"
                  subtitle="Daftar barang yang butuh restock agar penjualan tidak terhambat."
                >
                  {lowStockItems.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="min-w-full text-sm">
                        <thead>
                          <tr className="border-b border-slate-200 text-left text-slate-500">
                            <th className="px-3 py-3">Nama barang</th>
                            <th className="px-3 py-3">Stok</th>
                            <th className="px-3 py-3">Minimum</th>
                            <th className="px-3 py-3">Status</th>
                          </tr>
                        </thead>
                        <tbody>
                          {lowStockItems.map((item) => (
                            <tr key={item.id} className="border-b border-slate-100">
                              <td className="px-3 py-3 font-medium text-slate-700">{item.name}</td>
                              <td className="px-3 py-3 text-slate-600">{item.stock}</td>
                              <td className="px-3 py-3 text-slate-600">{item.minimumStock}</td>
                              <td className="px-3 py-3">
                                <Badge tone={item.stock === 0 ? "red" : "amber"}>
                                  {item.stock === 0 ? "Habis" : "Segera restock"}
                                </Badge>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <EmptyState title="Stok aman" description="Semua stok barang berada di atas batas minimum." />
                  )}
                </SectionCard>
              </div>
            </div>
          ) : null}

          {activeTab === "master" ? (
            <div className="space-y-6">
              <div className="grid gap-6 xl:grid-cols-2">
                <SectionCard
                  title="Tambah supplier / pelanggan"
                  subtitle="Fitur ini dikhususkan untuk admin agar database relasi usaha selalu rapi."
                  action={!canManageAdminOnly ? <Badge tone="amber">Hanya admin</Badge> : null}
                >
                  <form className="grid gap-4" onSubmit={handleAddContact}>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <label className="space-y-2 text-sm">
                        <span className="font-medium text-slate-700">Jenis kontak</span>
                        <select
                          value={contactForm.type}
                          disabled={!canManageAdminOnly}
                          onChange={(event) =>
                            setContactForm((prev) => ({
                              ...prev,
                              type: event.target.value as ContactType,
                            }))
                          }
                          className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100 disabled:bg-slate-100"
                        >
                          <option value="supplier">Supplier</option>
                          <option value="pelanggan">Pelanggan / Pembeli</option>
                        </select>
                      </label>
                      <label className="space-y-2 text-sm">
                        <span className="font-medium text-slate-700">Nama</span>
                        <input
                          value={contactForm.name}
                          disabled={!canManageAdminOnly}
                          onChange={(event) =>
                            setContactForm((prev) => ({ ...prev, name: event.target.value }))
                          }
                          className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100 disabled:bg-slate-100"
                          placeholder="Contoh: PT Bersih Makmur"
                        />
                      </label>
                    </div>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <label className="space-y-2 text-sm">
                        <span className="font-medium text-slate-700">Telepon</span>
                        <input
                          value={contactForm.phone}
                          disabled={!canManageAdminOnly}
                          onChange={(event) =>
                            setContactForm((prev) => ({ ...prev, phone: event.target.value }))
                          }
                          className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100 disabled:bg-slate-100"
                          placeholder="08xxxx atau nomor kantor"
                        />
                      </label>
                      <label className="space-y-2 text-sm">
                        <span className="font-medium text-slate-700">Alamat</span>
                        <input
                          value={contactForm.address}
                          disabled={!canManageAdminOnly}
                          onChange={(event) =>
                            setContactForm((prev) => ({ ...prev, address: event.target.value }))
                          }
                          className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100 disabled:bg-slate-100"
                          placeholder="Alamat lengkap"
                        />
                      </label>
                    </div>
                    <button
                      type="submit"
                      disabled={!canManageAdminOnly}
                      className="rounded-2xl bg-slate-950 px-4 py-3 font-semibold text-white transition hover:bg-sky-700 disabled:cursor-not-allowed disabled:bg-slate-300"
                    >
                      Simpan kontak
                    </button>
                  </form>
                </SectionCard>

                <SectionCard
                  title="Tambah barang / jasa"
                  subtitle="Simpan data nama item, satuan, harga beli, harga jual, diskon, supplier, dan stok minimum."
                  action={!canManageAdminOnly ? <Badge tone="amber">Hanya admin</Badge> : null}
                >
                  <form className="grid gap-4" onSubmit={handleAddCatalogItem}>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <label className="space-y-2 text-sm">
                        <span className="font-medium text-slate-700">Jenis</span>
                        <select
                          value={itemForm.kind}
                          disabled={!canManageAdminOnly}
                          onChange={(event) =>
                            setItemForm((prev) => ({
                              ...prev,
                              kind: event.target.value as CatalogKind,
                            }))
                          }
                          className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100 disabled:bg-slate-100"
                        >
                          <option value="barang">Barang</option>
                          <option value="jasa">Jasa</option>
                        </select>
                      </label>
                      <label className="space-y-2 text-sm">
                        <span className="font-medium text-slate-700">Nama barang / jasa</span>
                        <input
                          value={itemForm.name}
                          disabled={!canManageAdminOnly}
                          onChange={(event) =>
                            setItemForm((prev) => ({ ...prev, name: event.target.value }))
                          }
                          className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100 disabled:bg-slate-100"
                          placeholder="Contoh: Karbol Pembersih"
                        />
                      </label>
                    </div>
                    <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
                      <label className="space-y-2 text-sm">
                        <span className="font-medium text-slate-700">Satuan</span>
                        <input
                          value={itemForm.unit}
                          disabled={!canManageAdminOnly}
                          onChange={(event) =>
                            setItemForm((prev) => ({ ...prev, unit: event.target.value }))
                          }
                          className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100 disabled:bg-slate-100"
                          placeholder="pcs / liter / sesi"
                        />
                      </label>
                      <label className="space-y-2 text-sm">
                        <span className="font-medium text-slate-700">Harga beli</span>
                        <input
                          type="number"
                          value={itemForm.purchasePrice}
                          disabled={!canManageAdminOnly}
                          onChange={(event) =>
                            setItemForm((prev) => ({ ...prev, purchasePrice: event.target.value }))
                          }
                          className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100 disabled:bg-slate-100"
                          placeholder="0"
                        />
                      </label>
                      <label className="space-y-2 text-sm">
                        <span className="font-medium text-slate-700">Harga jual</span>
                        <input
                          type="number"
                          value={itemForm.salePrice}
                          disabled={!canManageAdminOnly}
                          onChange={(event) =>
                            setItemForm((prev) => ({ ...prev, salePrice: event.target.value }))
                          }
                          className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100 disabled:bg-slate-100"
                          placeholder="0"
                        />
                      </label>
                      <label className="space-y-2 text-sm">
                        <span className="font-medium text-slate-700">Diskon %</span>
                        <input
                          type="number"
                          value={itemForm.discount}
                          disabled={!canManageAdminOnly}
                          onChange={(event) =>
                            setItemForm((prev) => ({ ...prev, discount: event.target.value }))
                          }
                          className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100 disabled:bg-slate-100"
                          placeholder="0"
                        />
                      </label>
                    </div>
                    <div className="grid gap-4 sm:grid-cols-3">
                      <label className="space-y-2 text-sm sm:col-span-1">
                        <span className="font-medium text-slate-700">Supplier</span>
                        <select
                          value={itemForm.supplierId}
                          disabled={!canManageAdminOnly}
                          onChange={(event) =>
                            setItemForm((prev) => ({ ...prev, supplierId: event.target.value }))
                          }
                          className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100 disabled:bg-slate-100"
                        >
                          <option value="">Pilih supplier</option>
                          {suppliers.map((supplier) => (
                            <option key={supplier.id} value={supplier.id}>
                              {supplier.name}
                            </option>
                          ))}
                        </select>
                      </label>
                      <label className="space-y-2 text-sm">
                        <span className="font-medium text-slate-700">Stok awal</span>
                        <input
                          type="number"
                          value={itemForm.stock}
                          disabled={!canManageAdminOnly || itemForm.kind === "jasa"}
                          onChange={(event) =>
                            setItemForm((prev) => ({ ...prev, stock: event.target.value }))
                          }
                          className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100 disabled:bg-slate-100"
                          placeholder="0"
                        />
                      </label>
                      <label className="space-y-2 text-sm">
                        <span className="font-medium text-slate-700">Minimum stok</span>
                        <input
                          type="number"
                          value={itemForm.minimumStock}
                          disabled={!canManageAdminOnly || itemForm.kind === "jasa"}
                          onChange={(event) =>
                            setItemForm((prev) => ({ ...prev, minimumStock: event.target.value }))
                          }
                          className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100 disabled:bg-slate-100"
                          placeholder="0"
                        />
                      </label>
                    </div>
                    <button
                      type="submit"
                      disabled={!canManageAdminOnly}
                      className="rounded-2xl bg-slate-950 px-4 py-3 font-semibold text-white transition hover:bg-sky-700 disabled:cursor-not-allowed disabled:bg-slate-300"
                    >
                      Simpan barang / jasa
                    </button>
                  </form>
                </SectionCard>
              </div>

              <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
                <SectionCard
                  title="Daftar supplier & pelanggan"
                  subtitle="Tambah dan hapus data relasi usaha Anda."
                >
                  <div className="overflow-x-auto">
                    <table className="min-w-full text-sm">
                      <thead>
                        <tr className="border-b border-slate-200 text-left text-slate-500">
                          <th className="px-3 py-3">Nama</th>
                          <th className="px-3 py-3">Jenis</th>
                          <th className="px-3 py-3">Kontak</th>
                          <th className="px-3 py-3">Aksi</th>
                        </tr>
                      </thead>
                      <tbody>
                        {data.contacts.map((contact) => (
                          <tr key={contact.id} className="border-b border-slate-100 align-top">
                            <td className="px-3 py-3">
                              <p className="font-medium text-slate-700">{contact.name}</p>
                              <p className="mt-1 text-slate-500">{contact.address || "-"}</p>
                            </td>
                            <td className="px-3 py-3">
                              <Badge tone={contact.type === "supplier" ? "blue" : "green"}>{contact.type}</Badge>
                            </td>
                            <td className="px-3 py-3 text-slate-600">{contact.phone || "-"}</td>
                            <td className="px-3 py-3">
                              <button
                                type="button"
                                disabled={!canManageAdminOnly}
                                onClick={() => handleDeleteContact(contact)}
                                className="rounded-xl border border-rose-200 px-3 py-2 text-xs font-semibold text-rose-600 transition hover:bg-rose-50 disabled:cursor-not-allowed disabled:border-slate-200 disabled:text-slate-400"
                              >
                                Hapus
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </SectionCard>

                <SectionCard
                  title="Daftar barang & jasa"
                  subtitle="Master item yang digunakan untuk transaksi, stok, dan laporan."
                >
                  <div className="overflow-x-auto">
                    <table className="min-w-full text-sm">
                      <thead>
                        <tr className="border-b border-slate-200 text-left text-slate-500">
                          <th className="px-3 py-3">Nama item</th>
                          <th className="px-3 py-3">Jenis</th>
                          <th className="px-3 py-3">Harga beli</th>
                          <th className="px-3 py-3">Harga jual</th>
                          <th className="px-3 py-3">Stok</th>
                          <th className="px-3 py-3">Aksi</th>
                        </tr>
                      </thead>
                      <tbody>
                        {data.catalog.map((item) => (
                          <tr key={item.id} className="border-b border-slate-100 align-top">
                            <td className="px-3 py-3">
                              <p className="font-medium text-slate-700">{item.name}</p>
                              <p className="mt-1 text-slate-500">
                                {item.unit} • Diskon {item.discount}% • Supplier {contactMap[item.supplierId]?.name || "-"}
                              </p>
                            </td>
                            <td className="px-3 py-3">
                              <Badge tone={item.kind === "barang" ? "green" : "violet"}>{item.kind}</Badge>
                            </td>
                            <td className="px-3 py-3 text-slate-600">{formatCurrency(item.purchasePrice)}</td>
                            <td className="px-3 py-3 text-slate-600">{formatCurrency(item.salePrice)}</td>
                            <td className="px-3 py-3 text-slate-600">
                              {item.kind === "barang" ? `${item.stock} / min ${item.minimumStock}` : "Non stok"}
                            </td>
                            <td className="px-3 py-3">
                              <button
                                type="button"
                                disabled={!canManageAdminOnly}
                                onClick={() => handleDeleteCatalogItem(item)}
                                className="rounded-xl border border-rose-200 px-3 py-2 text-xs font-semibold text-rose-600 transition hover:bg-rose-50 disabled:cursor-not-allowed disabled:border-slate-200 disabled:text-slate-400"
                              >
                                Hapus
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </SectionCard>
              </div>
            </div>
          ) : null}

          {activeTab === "stock" ? (
            <div className="space-y-6">
              <SectionCard
                title="Data stok barang"
                subtitle="Monitoring stok terkini, minimum stok, nilai persediaan, dan trend item terjual."
              >
                <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                  <MetricCard
                    label="Total item aktif"
                    value={String(data.catalog.length)}
                    helper="Gabungan barang dan jasa dalam master data"
                  />
                  <MetricCard
                    label="Barang fisik"
                    value={String(data.catalog.filter((item) => item.kind === "barang").length)}
                    helper="Item dengan stok yang terpantau"
                  />
                  <MetricCard
                    label="Nilai stok"
                    value={formatCurrency(inventoryValue)}
                    helper="Estimasi aset persediaan berdasarkan HPP"
                  />
                  <MetricCard
                    label="Perlu restock"
                    value={String(lowStockItems.length)}
                    helper="Barang mencapai batas minimum stok"
                  />
                </div>
              </SectionCard>

              <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
                <SectionCard
                  title="Tabel stok & minimum stok"
                  subtitle="User dapat melihat, admin dapat memantau kebutuhan pembelian."
                >
                  <div className="overflow-x-auto">
                    <table className="min-w-full text-sm">
                      <thead>
                        <tr className="border-b border-slate-200 text-left text-slate-500">
                          <th className="px-3 py-3">Nama</th>
                          <th className="px-3 py-3">Satuan</th>
                          <th className="px-3 py-3">Stok</th>
                          <th className="px-3 py-3">Minimum</th>
                          <th className="px-3 py-3">Terjual</th>
                          <th className="px-3 py-3">Status</th>
                        </tr>
                      </thead>
                      <tbody>
                        {data.catalog.map((item) => {
                          const isLow = item.kind === "barang" && item.stock <= item.minimumStock;
                          return (
                            <tr key={item.id} className="border-b border-slate-100">
                              <td className="px-3 py-3 font-medium text-slate-700">{item.name}</td>
                              <td className="px-3 py-3 text-slate-600">{item.unit}</td>
                              <td className="px-3 py-3 text-slate-600">
                                {item.kind === "barang" ? item.stock : "-"}
                              </td>
                              <td className="px-3 py-3 text-slate-600">
                                {item.kind === "barang" ? item.minimumStock : "-"}
                              </td>
                              <td className="px-3 py-3 text-slate-600">{formatNumber(item.soldCount)}</td>
                              <td className="px-3 py-3">
                                {item.kind === "jasa" ? (
                                  <Badge tone="violet">Jasa</Badge>
                                ) : isLow ? (
                                  <Badge tone={item.stock === 0 ? "red" : "amber"}>
                                    {item.stock === 0 ? "Habis" : "Minimum"}
                                  </Badge>
                                ) : (
                                  <Badge tone="green">Aman</Badge>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </SectionCard>

                <SectionCard
                  title="Trend barang/jasa terjual"
                  subtitle="Semakin tinggi bar, semakin banyak item yang sudah terjual."
                >
                  <div className="space-y-4">
                    {topSellingItems.length > 0 ? (
                      topSellingItems.map((item) => (
                        <div key={item.id} className="space-y-2">
                          <div className="flex items-center justify-between text-sm">
                            <span className="font-medium text-slate-700">{item.name}</span>
                            <span className="text-slate-500">{formatNumber(item.soldCount)} terjual</span>
                          </div>
                          <div className="h-4 overflow-hidden rounded-full bg-slate-100">
                            <div
                              className={`h-full rounded-full ${
                                item.kind === "barang"
                                  ? "bg-gradient-to-r from-emerald-500 to-lime-500"
                                  : "bg-gradient-to-r from-violet-500 to-fuchsia-500"
                              }`}
                              style={{ width: `${Math.max((item.soldCount / maxTopSelling) * 100, 8)}%` }}
                            />
                          </div>
                        </div>
                      ))
                    ) : (
                      <EmptyState title="Belum ada tren penjualan" description="Silakan input transaksi untuk melihat trend item terjual." />
                    )}
                  </div>
                </SectionCard>
              </div>
            </div>
          ) : null}

          {activeTab === "sales" ? (
            <div className="space-y-6">
              <div className="grid gap-6 xl:grid-cols-[0.95fr_1.05fr]">
                <SectionCard
                  title="Input penjualan barang dan jasa"
                  subtitle="Pilih pelanggan, tambahkan item penjualan, lalu simpan transaksi."
                >
                  <form className="space-y-5" onSubmit={handleSaveSale}>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <label className="space-y-2 text-sm">
                        <span className="font-medium text-slate-700">Pelanggan / Pembeli</span>
                        <select
                          value={saleDraft.customerId}
                          onChange={(event) => {
                            const customer = customers.find((item) => item.id === event.target.value);
                            setSaleDraft((prev) => ({
                              ...prev,
                              customerId: event.target.value,
                              shippingAddress: customer?.address || prev.shippingAddress,
                            }));
                          }}
                          className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
                        >
                          <option value="">Pilih pelanggan</option>
                          {customers.map((customer) => (
                            <option key={customer.id} value={customer.id}>
                              {customer.name}
                            </option>
                          ))}
                        </select>
                      </label>
                      <label className="space-y-2 text-sm">
                        <span className="font-medium text-slate-700">Tanggal transaksi</span>
                        <input
                          type="date"
                          value={saleDraft.date}
                          onChange={(event) =>
                            setSaleDraft((prev) => ({ ...prev, date: event.target.value }))
                          }
                          className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
                        />
                      </label>
                    </div>

                    <label className="block space-y-2 text-sm">
                      <span className="font-medium text-slate-700">Alamat kirim / lokasi jasa</span>
                      <textarea
                        value={saleDraft.shippingAddress}
                        onChange={(event) =>
                          setSaleDraft((prev) => ({ ...prev, shippingAddress: event.target.value }))
                        }
                        className="min-h-24 w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
                        placeholder="Alamat pengiriman barang atau lokasi pelaksanaan jasa"
                      />
                    </label>

                    <div className="rounded-3xl border border-slate-200 bg-slate-50 p-4">
                      <div className="mb-4 flex items-center justify-between gap-3">
                        <div>
                          <h3 className="font-semibold text-slate-900">Tambah item ke draft</h3>
                          <p className="text-sm text-slate-500">Stok barang akan berkurang setelah transaksi disimpan.</p>
                        </div>
                        <Badge tone="blue">Transaksi aktif</Badge>
                      </div>
                      <div className="grid gap-4 sm:grid-cols-[1fr_140px_auto]">
                        <label className="space-y-2 text-sm">
                          <span className="font-medium text-slate-700">Barang / jasa</span>
                          <select
                            value={lineDraft.itemId}
                            onChange={(event) =>
                              setLineDraft((prev) => ({ ...prev, itemId: event.target.value }))
                            }
                            className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
                          >
                            <option value="">Pilih item</option>
                            {data.catalog.map((item) => (
                              <option key={item.id} value={item.id}>
                                {item.name} • {item.kind} • {formatCurrency(item.salePrice)}
                                {item.kind === "barang" ? ` • stok ${item.stock}` : ""}
                              </option>
                            ))}
                          </select>
                        </label>
                        <label className="space-y-2 text-sm">
                          <span className="font-medium text-slate-700">Qty</span>
                          <input
                            type="number"
                            min="1"
                            value={lineDraft.qty}
                            onChange={(event) =>
                              setLineDraft((prev) => ({ ...prev, qty: event.target.value }))
                            }
                            className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
                          />
                        </label>
                        <div className="flex items-end">
                          <button
                            type="button"
                            onClick={handleAddSaleLine}
                            className="w-full rounded-2xl bg-slate-950 px-4 py-3 font-semibold text-white transition hover:bg-sky-700"
                          >
                            Tambah
                          </button>
                        </div>
                      </div>
                    </div>

                    <label className="block space-y-2 text-sm">
                      <span className="font-medium text-slate-700">Catatan transaksi</span>
                      <textarea
                        value={saleDraft.notes}
                        onChange={(event) =>
                          setSaleDraft((prev) => ({ ...prev, notes: event.target.value }))
                        }
                        className="min-h-24 w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
                        placeholder="Contoh: pengiriman sore, pembayaran termin, teknisi wajib hadir pukul 08.00"
                      />
                    </label>

                    <button
                      type="submit"
                      className="w-full rounded-2xl bg-emerald-600 px-4 py-3 font-semibold text-white transition hover:bg-emerald-700"
                    >
                      Simpan penjualan
                    </button>
                  </form>
                </SectionCard>

                <SectionCard
                  title="Draft transaksi"
                  subtitle="Periksa item, subtotal, diskon, dan total sebelum transaksi disimpan."
                >
                  {saleDraft.items.length > 0 ? (
                    <div className="space-y-4">
                      <div className="overflow-x-auto">
                        <table className="min-w-full text-sm">
                          <thead>
                            <tr className="border-b border-slate-200 text-left text-slate-500">
                              <th className="px-3 py-3">Item</th>
                              <th className="px-3 py-3">Qty</th>
                              <th className="px-3 py-3">Harga</th>
                              <th className="px-3 py-3">Diskon</th>
                              <th className="px-3 py-3">Subtotal</th>
                              <th className="px-3 py-3">Aksi</th>
                            </tr>
                          </thead>
                          <tbody>
                            {saleDraft.items.map((line) => (
                              <tr key={line.id} className="border-b border-slate-100">
                                <td className="px-3 py-3">
                                  <p className="font-medium text-slate-700">{line.name}</p>
                                  <p className="mt-1 text-slate-500">{line.kind} • {line.unit}</p>
                                </td>
                                <td className="px-3 py-3 text-slate-600">{line.qty}</td>
                                <td className="px-3 py-3 text-slate-600">{formatCurrency(line.unitPrice)}</td>
                                <td className="px-3 py-3 text-slate-600">{line.discount}%</td>
                                <td className="px-3 py-3 font-medium text-slate-700">{formatCurrency(line.subtotal)}</td>
                                <td className="px-3 py-3">
                                  <button
                                    type="button"
                                    onClick={() => handleRemoveDraftLine(line.id)}
                                    className="rounded-xl border border-rose-200 px-3 py-2 text-xs font-semibold text-rose-600 transition hover:bg-rose-50"
                                  >
                                    Hapus
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      <div className="grid gap-4 sm:grid-cols-3">
                        <div className="rounded-2xl bg-slate-50 p-4">
                          <p className="text-sm text-slate-500">Subtotal bruto</p>
                          <p className="mt-2 text-lg font-semibold text-slate-900">{formatCurrency(draftGross)}</p>
                        </div>
                        <div className="rounded-2xl bg-slate-50 p-4">
                          <p className="text-sm text-slate-500">Total diskon</p>
                          <p className="mt-2 text-lg font-semibold text-slate-900">{formatCurrency(draftDiscount)}</p>
                        </div>
                        <div className="rounded-2xl bg-slate-950 p-4 text-white">
                          <p className="text-sm text-slate-300">Total bayar</p>
                          <p className="mt-2 text-lg font-semibold">{formatCurrency(draftTotal)}</p>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <EmptyState
                      title="Draft masih kosong"
                      description="Tambahkan barang atau jasa terlebih dahulu untuk membuat transaksi penjualan."
                    />
                  )}
                </SectionCard>
              </div>

              <SectionCard
                title="Transaksi terbaru"
                subtitle="Riwayat transaksi yang sudah tersimpan dan siap dicetak menjadi invoice atau surat jalan."
              >
                {data.sales.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="min-w-full text-sm">
                      <thead>
                        <tr className="border-b border-slate-200 text-left text-slate-500">
                          <th className="px-3 py-3">Invoice</th>
                          <th className="px-3 py-3">Tanggal</th>
                          <th className="px-3 py-3">Pelanggan</th>
                          <th className="px-3 py-3">Jumlah item</th>
                          <th className="px-3 py-3">Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {data.sales.slice(0, 8).map((sale) => (
                          <tr key={sale.id} className="border-b border-slate-100">
                            <td className="px-3 py-3 font-medium text-slate-700">{sale.code}</td>
                            <td className="px-3 py-3 text-slate-600">{formatDateLabel(sale.date)}</td>
                            <td className="px-3 py-3 text-slate-600">{sale.customerName}</td>
                            <td className="px-3 py-3 text-slate-600">{sale.items.length}</td>
                            <td className="px-3 py-3 text-slate-600">{formatCurrency(sale.total)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <EmptyState title="Belum ada transaksi" description="Silakan simpan penjualan pertama Anda dari form di atas." />
                )}
              </SectionCard>
            </div>
          ) : null}

          {activeTab === "documents" ? (
            <div className="space-y-6">
              <SectionCard
                title="Invoice dan surat jalan"
                subtitle="Pilih transaksi untuk melihat pratinjau dokumen dan cetak ke PDF atau printer yang terinstal."
                action={selectedSale ? <Badge tone="green">Dokumen siap dicetak</Badge> : null}
              >
                {data.sales.length > 0 ? (
                  <div className="grid gap-6 xl:grid-cols-[320px_1fr]">
                    <div className="space-y-4">
                      <label className="block space-y-2 text-sm">
                        <span className="font-medium text-slate-700">Pilih transaksi</span>
                        <select
                          value={selectedSaleId}
                          onChange={(event) => setSelectedSaleId(event.target.value)}
                          className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
                        >
                          {data.sales.map((sale) => (
                            <option key={sale.id} value={sale.id}>
                              {sale.code} • {sale.customerName}
                            </option>
                          ))}
                        </select>
                      </label>

                      {selectedSale ? (
                        <div className="rounded-3xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-600">
                          <p className="font-semibold text-slate-900">{selectedSale.code}</p>
                          <p className="mt-2">Tanggal: {formatDateLabel(selectedSale.date)}</p>
                          <p className="mt-1">Pelanggan: {selectedSale.customerName}</p>
                          <p className="mt-1">Alamat: {selectedSale.shippingAddress}</p>
                          <p className="mt-1">Total: {formatCurrency(selectedSale.total)}</p>
                        </div>
                      ) : null}

                      <div className="grid gap-3">
                        <button
                          type="button"
                          disabled={!selectedSale}
                          onClick={() => selectedSale && printInvoice(selectedSale)}
                          className="rounded-2xl bg-slate-950 px-4 py-3 font-semibold text-white transition hover:bg-sky-700 disabled:cursor-not-allowed disabled:bg-slate-300"
                        >
                          Cetak invoice
                        </button>
                        <button
                          type="button"
                          disabled={!selectedSale}
                          onClick={() => selectedSale && printDeliveryNote(selectedSale)}
                          className="rounded-2xl border border-slate-300 bg-white px-4 py-3 font-semibold text-slate-700 transition hover:bg-slate-50 disabled:cursor-not-allowed disabled:bg-slate-100"
                        >
                          Cetak surat jalan
                        </button>
                      </div>
                      <p className="text-sm text-slate-500">
                        Dialog print browser dapat dipakai untuk <strong>simpan PDF</strong> atau mengirim
                        langsung ke <strong>printer yang terinstal</strong>.
                      </p>
                    </div>

                    {selectedSale ? (
                      <div className="grid gap-6 xl:grid-cols-2">
                        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
                          <div className="flex items-center justify-between gap-3">
                            <div>
                              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-500">Invoice</p>
                              <h3 className="mt-1 text-xl font-semibold">{selectedSale.code}</h3>
                            </div>
                            <Badge tone="blue">Pratinjau</Badge>
                          </div>
                          <div className="mt-6 grid gap-4 text-sm md:grid-cols-2">
                            <div className="rounded-2xl bg-slate-50 p-4">
                              <p className="font-semibold text-slate-900">Pelanggan</p>
                              <p className="mt-2">{selectedSale.customerName}</p>
                              <p className="mt-1 text-slate-500">{selectedSale.shippingAddress}</p>
                            </div>
                            <div className="rounded-2xl bg-slate-50 p-4">
                              <p className="font-semibold text-slate-900">Ringkasan</p>
                              <p className="mt-2">Tanggal: {formatDateLabel(selectedSale.date)}</p>
                              <p className="mt-1">Diskon: {formatCurrency(selectedSale.discountAmount)}</p>
                              <p className="mt-1">Total: {formatCurrency(selectedSale.total)}</p>
                            </div>
                          </div>
                          <div className="mt-6 overflow-x-auto">
                            <table className="min-w-full text-sm">
                              <thead>
                                <tr className="border-b border-slate-200 text-left text-slate-500">
                                  <th className="px-3 py-3">Item</th>
                                  <th className="px-3 py-3">Qty</th>
                                  <th className="px-3 py-3">Harga</th>
                                  <th className="px-3 py-3">Subtotal</th>
                                </tr>
                              </thead>
                              <tbody>
                                {selectedSale.items.map((line) => (
                                  <tr key={line.id} className="border-b border-slate-100">
                                    <td className="px-3 py-3 font-medium text-slate-700">{line.name}</td>
                                    <td className="px-3 py-3 text-slate-600">{line.qty} {line.unit}</td>
                                    <td className="px-3 py-3 text-slate-600">{formatCurrency(line.unitPrice)}</td>
                                    <td className="px-3 py-3 text-slate-600">{formatCurrency(line.subtotal)}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>

                        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
                          <div className="flex items-center justify-between gap-3">
                            <div>
                              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-500">Surat jalan</p>
                              <h3 className="mt-1 text-xl font-semibold">SJ-{selectedSale.code}</h3>
                            </div>
                            <Badge tone="green">Pengiriman / jasa</Badge>
                          </div>
                          <div className="mt-6 space-y-4 text-sm text-slate-600">
                            <div className="rounded-2xl bg-slate-50 p-4">
                              <p className="font-semibold text-slate-900">Tujuan</p>
                              <p className="mt-2">{selectedSale.customerName}</p>
                              <p className="mt-1">{selectedSale.shippingAddress}</p>
                            </div>
                            <div className="rounded-2xl bg-slate-50 p-4">
                              <p className="font-semibold text-slate-900">Catatan</p>
                              <p className="mt-2">{selectedSale.notes || "Tidak ada catatan tambahan."}</p>
                            </div>
                            <div className="overflow-x-auto">
                              <table className="min-w-full text-sm">
                                <thead>
                                  <tr className="border-b border-slate-200 text-left text-slate-500">
                                    <th className="px-3 py-3">Item / jasa</th>
                                    <th className="px-3 py-3">Qty</th>
                                    <th className="px-3 py-3">Keterangan</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {selectedSale.items.map((line) => (
                                    <tr key={line.id} className="border-b border-slate-100">
                                      <td className="px-3 py-3 font-medium text-slate-700">{line.name}</td>
                                      <td className="px-3 py-3 text-slate-600">{line.qty} {line.unit}</td>
                                      <td className="px-3 py-3 text-slate-600">
                                        {line.kind === "barang" ? "Barang dikirim" : "Jasa dilaksanakan"}
                                      </td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <EmptyState title="Pilih transaksi" description="Pilih salah satu transaksi untuk melihat invoice dan surat jalan." />
                    )}
                  </div>
                ) : (
                  <EmptyState title="Belum ada dokumen" description="Simpan penjualan terlebih dahulu untuk membuat invoice dan surat jalan." />
                )}
              </SectionCard>
            </div>
          ) : null}

          {activeTab === "reports" ? (
            <div className="space-y-6">
              <SectionCard
                title="Laporan keuangan"
                subtitle="Analisis omzet, HPP, biaya, diskon, dan laba untuk periode harian, mingguan, bulanan, atau tahunan."
                action={
                  <div className="flex flex-wrap items-center gap-3">
                    <Badge tone="blue">Periode: {reportLabel}</Badge>
                    <button
                      type="button"
                      onClick={printReport}
                      className="rounded-2xl border border-slate-300 bg-white px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-50"
                    >
                      Cetak laporan
                    </button>
                  </div>
                }
              >
                <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-[220px_220px_1fr]">
                  <label className="space-y-2 text-sm">
                    <span className="font-medium text-slate-700">Jenis periode</span>
                    <select
                      value={reportPeriod}
                      onChange={(event) => setReportPeriod(event.target.value as ReportPeriod)}
                      className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
                    >
                      <option value="harian">Harian</option>
                      <option value="mingguan">Mingguan</option>
                      <option value="bulanan">Bulanan</option>
                      <option value="tahunan">Tahunan</option>
                    </select>
                  </label>
                  <label className="space-y-2 text-sm">
                    <span className="font-medium text-slate-700">Tanggal acuan</span>
                    <input
                      type="date"
                      value={reportDate}
                      onChange={(event) => setReportDate(event.target.value)}
                      className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100"
                    />
                  </label>
                  <div className="rounded-2xl bg-slate-50 p-4 text-sm text-slate-600">
                    <p className="font-semibold text-slate-900">Ringkasan periode</p>
                    <p className="mt-2">Laporan aktif: {reportLabel}</p>
                    <p className="mt-1">Jumlah transaksi: {formatNumber(reportSales.length)}</p>
                    <p className="mt-1">Jumlah biaya operasional: {formatNumber(reportExpenses.length)}</p>
                  </div>
                </div>
              </SectionCard>

              <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
                <MetricCard label="Omzet" value={formatCurrency(reportRevenue)} helper="Total penjualan bersih" />
                <MetricCard label="Diskon" value={formatCurrency(reportDiscount)} helper="Akumulasi diskon transaksi" />
                <MetricCard label="HPP" value={formatCurrency(reportCost)} helper="Estimasi modal barang/jasa" />
                <MetricCard label="Biaya" value={formatCurrency(reportExpenseTotal)} helper="Biaya operasional periode ini" />
                <MetricCard label="Laba bersih" value={formatCurrency(reportNetProfit)} helper="Omzet - HPP - biaya" />
              </div>

              <div className="grid gap-6 xl:grid-cols-[1.1fr_0.9fr]">
                <SectionCard
                  title="Rincian transaksi"
                  subtitle="Daftar invoice yang termasuk pada periode laporan terpilih."
                >
                  {reportSales.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="min-w-full text-sm">
                        <thead>
                          <tr className="border-b border-slate-200 text-left text-slate-500">
                            <th className="px-3 py-3">Invoice</th>
                            <th className="px-3 py-3">Tanggal</th>
                            <th className="px-3 py-3">Pelanggan</th>
                            <th className="px-3 py-3">Diskon</th>
                            <th className="px-3 py-3">Total</th>
                          </tr>
                        </thead>
                        <tbody>
                          {reportSales.map((sale) => (
                            <tr key={sale.id} className="border-b border-slate-100">
                              <td className="px-3 py-3 font-medium text-slate-700">{sale.code}</td>
                              <td className="px-3 py-3 text-slate-600">{formatDateLabel(sale.date)}</td>
                              <td className="px-3 py-3 text-slate-600">{sale.customerName}</td>
                              <td className="px-3 py-3 text-slate-600">{formatCurrency(sale.discountAmount)}</td>
                              <td className="px-3 py-3 text-slate-600">{formatCurrency(sale.total)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <EmptyState title="Tidak ada transaksi" description="Belum ada penjualan pada periode yang dipilih." />
                  )}
                </SectionCard>

                <SectionCard
                  title="Biaya operasional periode"
                  subtitle="Data ini ikut memengaruhi perhitungan laba bersih pada laporan."
                >
                  {reportExpenses.length > 0 ? (
                    <div className="space-y-3">
                      {reportExpenses.map((expense) => (
                        <div key={expense.id} className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                          <div className="flex items-start justify-between gap-4">
                            <div>
                              <p className="font-semibold text-slate-900">{expense.category}</p>
                              <p className="mt-1 text-sm text-slate-600">{expense.description}</p>
                              <p className="mt-2 text-xs text-slate-500">{formatDateLabel(expense.date)}</p>
                            </div>
                            <p className="text-sm font-semibold text-slate-900">{formatCurrency(expense.amount)}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <EmptyState title="Tidak ada biaya" description="Belum ada biaya operasional pada periode laporan ini." />
                  )}
                </SectionCard>
              </div>
            </div>
          ) : null}

          {activeTab === "profit" ? (
            <div className="space-y-6">
              <SectionCard
                title="Neraca internal & laba rugi"
                subtitle="Ringkasan posisi usaha berdasarkan penjualan, persediaan, dan biaya operasional yang dicatat."
              >
                <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
                  <MetricCard
                    label="Aset persediaan"
                    value={formatCurrency(inventoryValue)}
                    helper="Berdasarkan stok tersisa × harga beli"
                  />
                  <MetricCard
                    label="Laba kotor"
                    value={formatCurrency(grossProfit)}
                    helper="Total omzet dikurangi HPP"
                  />
                  <MetricCard
                    label="Biaya operasional"
                    value={formatCurrency(allExpenses)}
                    helper="Akumulasi semua biaya usaha"
                  />
                  <MetricCard
                    label="Laba bersih usaha"
                    value={formatCurrency(netProfit)}
                    helper="Kinerja bersih usaha hingga saat ini"
                  />
                </div>
              </SectionCard>

              <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
                <SectionCard
                  title="Input biaya operasional"
                  subtitle="Admin dapat mencatat biaya harian, mingguan, atau bulanan yang memengaruhi laba bersih."
                  action={!canManageAdminOnly ? <Badge tone="amber">Hanya admin</Badge> : null}
                >
                  <form className="space-y-4" onSubmit={handleAddExpense}>
                    <div className="grid gap-4 sm:grid-cols-2">
                      <label className="space-y-2 text-sm">
                        <span className="font-medium text-slate-700">Tanggal</span>
                        <input
                          type="date"
                          value={expenseForm.date}
                          disabled={!canManageAdminOnly}
                          onChange={(event) =>
                            setExpenseForm((prev) => ({ ...prev, date: event.target.value }))
                          }
                          className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100 disabled:bg-slate-100"
                        />
                      </label>
                      <label className="space-y-2 text-sm">
                        <span className="font-medium text-slate-700">Kategori</span>
                        <input
                          value={expenseForm.category}
                          disabled={!canManageAdminOnly}
                          onChange={(event) =>
                            setExpenseForm((prev) => ({ ...prev, category: event.target.value }))
                          }
                          className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100 disabled:bg-slate-100"
                          placeholder="Transport / Operasional / Gaji"
                        />
                      </label>
                    </div>
                    <label className="block space-y-2 text-sm">
                      <span className="font-medium text-slate-700">Deskripsi</span>
                      <textarea
                        value={expenseForm.description}
                        disabled={!canManageAdminOnly}
                        onChange={(event) =>
                          setExpenseForm((prev) => ({ ...prev, description: event.target.value }))
                        }
                        className="min-h-24 w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100 disabled:bg-slate-100"
                        placeholder="Contoh: beli BBM untuk pengiriman barang"
                      />
                    </label>
                    <label className="block space-y-2 text-sm">
                      <span className="font-medium text-slate-700">Nominal</span>
                      <input
                        type="number"
                        value={expenseForm.amount}
                        disabled={!canManageAdminOnly}
                        onChange={(event) =>
                          setExpenseForm((prev) => ({ ...prev, amount: event.target.value }))
                        }
                        className="w-full rounded-2xl border border-slate-300 px-4 py-3 outline-none focus:border-sky-500 focus:ring-4 focus:ring-sky-100 disabled:bg-slate-100"
                        placeholder="0"
                      />
                    </label>
                    <button
                      type="submit"
                      disabled={!canManageAdminOnly}
                      className="w-full rounded-2xl bg-slate-950 px-4 py-3 font-semibold text-white transition hover:bg-sky-700 disabled:cursor-not-allowed disabled:bg-slate-300"
                    >
                      Simpan biaya operasional
                    </button>
                  </form>
                </SectionCard>

                <SectionCard
                  title="Ringkasan neraca & laba rugi"
                  subtitle="Format internal untuk memantau posisi aset, kewajiban, ekuitas, dan performa usaha."
                >
                  <div className="grid gap-6 lg:grid-cols-2">
                    <div className="rounded-3xl border border-slate-200 bg-slate-50 p-5">
                      <h3 className="text-base font-semibold text-slate-900">Neraca internal</h3>
                      <div className="mt-4 space-y-3 text-sm text-slate-600">
                        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                          <span>Aset persediaan</span>
                          <strong className="text-slate-900">{formatCurrency(inventoryValue)}</strong>
                        </div>
                        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                          <span>Saldo usaha (estimasi)</span>
                          <strong className="text-slate-900">{formatCurrency(netProfit)}</strong>
                        </div>
                        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                          <span>Total aset</span>
                          <strong className="text-slate-900">{formatCurrency(totalAssets)}</strong>
                        </div>
                        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                          <span>Total kewajiban</span>
                          <strong className="text-slate-900">{formatCurrency(totalLiabilities)}</strong>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Ekuitas</span>
                          <strong className="text-slate-900">{formatCurrency(totalEquity)}</strong>
                        </div>
                      </div>
                    </div>
                    <div className="rounded-3xl border border-slate-200 bg-slate-50 p-5">
                      <h3 className="text-base font-semibold text-slate-900">Laba rugi kumulatif</h3>
                      <div className="mt-4 space-y-3 text-sm text-slate-600">
                        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                          <span>Pendapatan</span>
                          <strong className="text-slate-900">{formatCurrency(allRevenue)}</strong>
                        </div>
                        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                          <span>Harga pokok penjualan</span>
                          <strong className="text-slate-900">{formatCurrency(allCost)}</strong>
                        </div>
                        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                          <span>Laba kotor</span>
                          <strong className="text-slate-900">{formatCurrency(grossProfit)}</strong>
                        </div>
                        <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                          <span>Biaya operasional</span>
                          <strong className="text-slate-900">{formatCurrency(allExpenses)}</strong>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Laba bersih</span>
                          <strong className="text-slate-900">{formatCurrency(netProfit)}</strong>
                        </div>
                      </div>
                    </div>
                  </div>
                </SectionCard>
              </div>

              <SectionCard
                title="Daftar biaya operasional"
                subtitle="Semua biaya yang sudah dicatat untuk mendukung laporan keuangan dan laba rugi."
              >
                {data.expenses.length > 0 ? (
                  <div className="overflow-x-auto">
                    <table className="min-w-full text-sm">
                      <thead>
                        <tr className="border-b border-slate-200 text-left text-slate-500">
                          <th className="px-3 py-3">Tanggal</th>
                          <th className="px-3 py-3">Kategori</th>
                          <th className="px-3 py-3">Deskripsi</th>
                          <th className="px-3 py-3">Nominal</th>
                          <th className="px-3 py-3">Aksi</th>
                        </tr>
                      </thead>
                      <tbody>
                        {data.expenses.map((expense) => (
                          <tr key={expense.id} className="border-b border-slate-100">
                            <td className="px-3 py-3 text-slate-600">{formatDateLabel(expense.date)}</td>
                            <td className="px-3 py-3 font-medium text-slate-700">{expense.category}</td>
                            <td className="px-3 py-3 text-slate-600">{expense.description}</td>
                            <td className="px-3 py-3 text-slate-600">{formatCurrency(expense.amount)}</td>
                            <td className="px-3 py-3">
                              <button
                                type="button"
                                disabled={!canManageAdminOnly}
                                onClick={() => handleDeleteExpense(expense.id)}
                                className="rounded-xl border border-rose-200 px-3 py-2 text-xs font-semibold text-rose-600 transition hover:bg-rose-50 disabled:cursor-not-allowed disabled:border-slate-200 disabled:text-slate-400"
                              >
                                Hapus
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <EmptyState title="Belum ada biaya" description="Tambahkan biaya operasional untuk melengkapi laporan laba rugi." />
                )}
              </SectionCard>
            </div>
          ) : null}

          {activeTab === "storage" ? (
            <div className="space-y-6">
              <SectionCard
                title="Backup data dan pusat cetak"
                subtitle="Data tersimpan otomatis di browser sebagai virtual harddisk, lalu dapat diekspor untuk backup ke Google Drive."
              >
                <div className="grid gap-6 xl:grid-cols-[0.9fr_1.1fr]">
                  <div className="space-y-4 rounded-3xl border border-slate-200 bg-slate-50 p-5">
                    <h3 className="text-base font-semibold text-slate-900">Penyimpanan data</h3>
                    <p className="text-sm text-slate-600">
                      Mode <strong>virtual harddisk</strong> memakai local storage browser untuk auto-save.
                      Mode <strong>Google Drive</strong> memakai file backup JSON yang dapat diunduh lalu diunggah ke Drive.
                    </p>
                    <div className="grid gap-3">
                      <button
                        type="button"
                        onClick={() =>
                          setData((prev) => ({
                            ...prev,
                            storage: { ...prev.storage, target: "virtual-disk" },
                          }))
                        }
                        className={`rounded-2xl border px-4 py-3 text-left transition ${
                          data.storage.target === "virtual-disk"
                            ? "border-emerald-300 bg-emerald-50"
                            : "border-slate-200 bg-white hover:bg-slate-50"
                        }`}
                      >
                        <p className="font-semibold text-slate-900">Virtual Harddisk Browser</p>
                        <p className="mt-1 text-sm text-slate-500">Auto-save langsung pada perangkat/browser saat ini.</p>
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          setData((prev) => ({
                            ...prev,
                            storage: { ...prev.storage, target: "google-drive" },
                          }))
                        }
                        className={`rounded-2xl border px-4 py-3 text-left transition ${
                          data.storage.target === "google-drive"
                            ? "border-violet-300 bg-violet-50"
                            : "border-slate-200 bg-white hover:bg-slate-50"
                        }`}
                      >
                        <p className="font-semibold text-slate-900">Backup Google Drive</p>
                        <p className="mt-1 text-sm text-slate-500">Unduh file JSON lalu simpan ke folder Google Drive Anda.</p>
                      </button>
                    </div>
                    <div className="rounded-2xl bg-white p-4 text-sm text-slate-600">
                      <p className="font-semibold text-slate-900">Status backup terakhir</p>
                      <p className="mt-2">
                        {data.storage.lastBackupAt
                          ? new Intl.DateTimeFormat("id-ID", {
                              dateStyle: "medium",
                              timeStyle: "short",
                            }).format(new Date(data.storage.lastBackupAt))
                          : "Belum pernah melakukan backup manual"}
                      </p>
                    </div>
                  </div>

                  <div className="space-y-4 rounded-3xl border border-slate-200 bg-white p-5">
                    <h3 className="text-base font-semibold text-slate-900">Aksi backup & restore</h3>
                    <div className="grid gap-3 sm:grid-cols-2">
                      <button
                        type="button"
                        onClick={handleExportBackup}
                        className="rounded-2xl bg-slate-950 px-4 py-3 font-semibold text-white transition hover:bg-sky-700"
                      >
                        Ekspor backup JSON
                      </button>
                      <label className="flex cursor-pointer items-center justify-center rounded-2xl border border-slate-300 bg-white px-4 py-3 font-semibold text-slate-700 transition hover:bg-slate-50">
                        Impor backup
                        <input type="file" accept="application/json" onChange={handleImportBackup} className="hidden" />
                      </label>
                    </div>
                    <div className="grid gap-4 md:grid-cols-3">
                      <div className="rounded-2xl bg-slate-50 p-4 text-sm text-slate-600">
                        <p className="font-semibold text-slate-900">Master data</p>
                        <p className="mt-2">{formatNumber(data.catalog.length)} barang/jasa</p>
                      </div>
                      <div className="rounded-2xl bg-slate-50 p-4 text-sm text-slate-600">
                        <p className="font-semibold text-slate-900">Relasi usaha</p>
                        <p className="mt-2">{formatNumber(data.contacts.length)} supplier/pelanggan</p>
                      </div>
                      <div className="rounded-2xl bg-slate-50 p-4 text-sm text-slate-600">
                        <p className="font-semibold text-slate-900">Transaksi</p>
                        <p className="mt-2">{formatNumber(data.sales.length)} invoice tersimpan</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      disabled={!canManageAdminOnly}
                      onClick={resetDemoData}
                      className="rounded-2xl border border-rose-300 bg-rose-50 px-4 py-3 font-semibold text-rose-700 transition hover:bg-rose-100 disabled:cursor-not-allowed disabled:border-slate-200 disabled:bg-slate-100 disabled:text-slate-400"
                    >
                      Reset ke data demo awal
                    </button>
                  </div>
                </div>
              </SectionCard>

              <div className="grid gap-6 xl:grid-cols-2">
                <SectionCard
                  title="Print center"
                  subtitle="Gunakan tombol cetak invoice, surat jalan, atau laporan sesuai kebutuhan."
                >
                  <div className="space-y-4 text-sm text-slate-600">
                    <div className="rounded-2xl bg-slate-50 p-4">
                      <p className="font-semibold text-slate-900">Cetak dokumen transaksi</p>
                      <p className="mt-2">
                        Buka tab <strong>Invoice & Surat Jalan</strong>, pilih transaksi, lalu klik cetak.
                      </p>
                    </div>
                    <div className="rounded-2xl bg-slate-50 p-4">
                      <p className="font-semibold text-slate-900">Cetak laporan keuangan</p>
                      <p className="mt-2">
                        Tab <strong>Laporan Keuangan</strong> sudah menyediakan tombol cetak laporan periode aktif.
                      </p>
                    </div>
                    <div className="rounded-2xl bg-slate-50 p-4">
                      <p className="font-semibold text-slate-900">PDF atau printer langsung</p>
                      <p className="mt-2">
                        Dialog print browser dapat dipilih untuk menyimpan sebagai PDF atau langsung mengirim ke printer terinstal.
                      </p>
                    </div>
                  </div>
                </SectionCard>

                <SectionCard
                  title="Catatan implementasi penyimpanan"
                  subtitle="Penjelasan singkat agar operasional backup dan restore lebih aman."
                >
                  <div className="space-y-4 text-sm text-slate-600">
                    <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                      <p className="font-semibold text-slate-900">1. Auto-save lokal</p>
                      <p className="mt-2">Semua perubahan langsung disimpan pada browser sebagai virtual harddisk lokal.</p>
                    </div>
                    <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                      <p className="font-semibold text-slate-900">2. Backup ke Google Drive</p>
                      <p className="mt-2">Klik ekspor JSON lalu unggah file backup ke Google Drive perusahaan agar aman dan mudah dipindahkan.</p>
                    </div>
                    <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                      <p className="font-semibold text-slate-900">3. Restore saat dibutuhkan</p>
                      <p className="mt-2">Gunakan impor backup untuk mengembalikan seluruh data transaksi, stok, kontak, dan laporan.</p>
                    </div>
                  </div>
                </SectionCard>
              </div>
            </div>
          ) : null}
        </main>
      </div>
    </div>
  );
}
